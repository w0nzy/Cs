﻿// Decompiled with JetBrains decompiler
// Type: Shelf.App
// Assembly: Shelf, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 34392FE8-51B4-4368-914A-8B6FB98A7971
// Assembly location: C:\Users\pc\reverse_engineering\com.companyname.Shelf\assemblies\Shelf.dll

using Shelf.Manager;
using Shelf.Views;
using System.CodeDom.Compiler;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace Shelf
{
  [XamlFilePath("Views\\App.xaml")]
  public class App : Application
  {
    public App()
    {
      this.InitializeComponent();
      GlobalMob.ButtonColor = Color.FromRgb(218, 18, 95);
      GlobalMob.TextColor = Color.White;
      Login login = new Login();
      ((Page) login).Title = "Raf Takip";
      this.MainPage = (Page) new NavigationPage((Page) login)
      {
        BarBackgroundColor = GlobalMob.ButtonColor
      };
    }

    protected virtual void OnStart()
    {
    }

    protected virtual void OnSleep()
    {
    }

    protected virtual void OnResume()
    {
    }

    [GeneratedCode("Xamarin.Forms.Build.Tasks.XamlG", "2.0.0.0")]
    private void InitializeComponent() => Extensions.LoadFromXaml<App>(this, typeof (App));
  }
}
