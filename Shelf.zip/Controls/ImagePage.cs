﻿// Decompiled with JetBrains decompiler
// Type: Shelf.Controls.ImagePage
// Assembly: Shelf, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 34392FE8-51B4-4368-914A-8B6FB98A7971
// Assembly location: C:\Users\pc\reverse_engineering\com.companyname.Shelf\assemblies\Shelf.dll

using System;
using System.CodeDom.Compiler;
using System.IO;
using System.Net;
using System.Reflection;
using Xamarin.Forms;
using Xamarin.Forms.Internals;
using Xamarin.Forms.Xaml;
using Xamarin.Forms.Xaml.Diagnostics;
using Xamarin.Forms.Xaml.Internals;

namespace Shelf.Controls
{
  [XamlCompilation]
  [XamlFilePath("Controls\\ImagePage.xaml")]
  public class ImagePage : ContentPage
  {
    public string ImgUrl;
    [GeneratedCode("Xamarin.Forms.Build.Tasks.XamlG", "2.0.0.0")]
    private Image imgas;

    public ImagePage(string url, string title)
    {
      this.ImgUrl = url;
      this.InitializeComponent();
      try
      {
        byte[] byteArray = new WebClient().DownloadData(url);
        ((VisualElement) this.imgas).BackgroundColor = Color.White;
        this.imgas.Aspect = (Aspect) 0;
        this.imgas.Source = ImageSource.FromStream((Func<Stream>) (() => (Stream) new MemoryStream(byteArray)));
      }
      catch (Exception ex)
      {
      }
      ((Page) this).Title = title;
    }

    [GeneratedCode("Xamarin.Forms.Build.Tasks.XamlG", "2.0.0.0")]
    private void InitializeComponent()
    {
      if (ResourceLoader.CanProvideContentFor(new ResourceLoader.ResourceLoadingQuery()
      {
        AssemblyName = typeof (ImagePage).GetTypeInfo().Assembly.GetName(),
        ResourcePath = "Controls/ImagePage.xaml",
        Instance = (object) this
      }))
        this.__InitComponentRuntime();
      else if (XamlLoader.XamlFileProvider != null && XamlLoader.XamlFileProvider(((object) this).GetType()) != null)
      {
        this.__InitComponentRuntime();
      }
      else
      {
        Image image = new Image();
        ImagePage imagePage;
        NameScope nameScope = (NameScope) (NameScope.GetNameScope((BindableObject) (imagePage = this)) ?? (INameScope) new NameScope());
        NameScope.SetNameScope((BindableObject) imagePage, (INameScope) nameScope);
        ((INameScope) nameScope).RegisterName("imgas", (object) image);
        if (((Element) image).StyleId == null)
          ((Element) image).StyleId = "imgas";
        this.imgas = image;
        ((BindableObject) image).SetValue(VisualElement.BackgroundColorProperty, (object) Color.Blue);
        ((BindableObject) image).SetValue(Image.AspectProperty, (object) (Aspect) 2);
        ((BindableObject) image).SetValue(View.VerticalOptionsProperty, (object) LayoutOptions.Fill);
        ((BindableObject) image).SetValue(View.HorizontalOptionsProperty, (object) LayoutOptions.FillAndExpand);
        ((BindableObject) image).SetValue(View.MarginProperty, (object) new Thickness(0.0));
        ((BindableObject) imagePage).SetValue(ContentPage.ContentProperty, (object) image);
        VisualDiagnostics.RegisterSourceInfo((object) image, new Uri("Controls\\ImagePage.xaml" + ";assembly=" + "Shelf", UriKind.RelativeOrAbsolute), 8, 6);
        VisualDiagnostics.RegisterSourceInfo((object) imagePage, new Uri("Controls\\ImagePage.xaml" + ";assembly=" + "Shelf", UriKind.RelativeOrAbsolute), 2, 2);
      }
    }

    private void __InitComponentRuntime()
    {
      Extensions.LoadFromXaml<ImagePage>(this, typeof (ImagePage));
      this.imgas = NameScopeExtensions.FindByName<Image>((Element) this, "imgas");
    }
  }
}
