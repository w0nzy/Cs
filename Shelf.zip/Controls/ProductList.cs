﻿// Decompiled with JetBrains decompiler
// Type: Shelf.Controls.ProductList
// Assembly: Shelf, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 34392FE8-51B4-4368-914A-8B6FB98A7971
// Assembly location: C:\Users\pc\reverse_engineering\com.companyname.Shelf\assemblies\Shelf.dll

using Shelf.Helpers;
using Shelf.Manager;
using Shelf.Models;
using System;
using System.CodeDom.Compiler;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using System.Threading.Tasks;
using System.Xml;
using Xamarin.Forms;
using Xamarin.Forms.Internals;
using Xamarin.Forms.Xaml;
using Xamarin.Forms.Xaml.Diagnostics;
using Xamarin.Forms.Xaml.Internals;

namespace Shelf.Controls
{
  [XamlCompilation]
  [XamlFilePath("Controls\\ProductList.xaml")]
  public class ProductList : ContentPage
  {
    private List<pIOGetShelfItemsReturnModel> productList;
    private ContentPage MasterPage;
    public pIOGetShelfItemsReturnModel selectedItem;
    public bool IsClose = true;
    [GeneratedCode("Xamarin.Forms.Build.Tasks.XamlG", "2.0.0.0")]
    private ContentPage product;
    [GeneratedCode("Xamarin.Forms.Build.Tasks.XamlG", "2.0.0.0")]
    private StackLayout stckProductList;
    [GeneratedCode("Xamarin.Forms.Build.Tasks.XamlG", "2.0.0.0")]
    private StackLayout stckProductMessage;
    [GeneratedCode("Xamarin.Forms.Build.Tasks.XamlG", "2.0.0.0")]
    private StackLayout stckSearch;
    [GeneratedCode("Xamarin.Forms.Build.Tasks.XamlG", "2.0.0.0")]
    private Xamarin.Forms.Entry Product_Search;
    [GeneratedCode("Xamarin.Forms.Build.Tasks.XamlG", "2.0.0.0")]
    private Picker pckSearch;
    [GeneratedCode("Xamarin.Forms.Build.Tasks.XamlG", "2.0.0.0")]
    private ImageButton imgSearch;
    [GeneratedCode("Xamarin.Forms.Build.Tasks.XamlG", "2.0.0.0")]
    private Button btnClear;
    [GeneratedCode("Xamarin.Forms.Build.Tasks.XamlG", "2.0.0.0")]
    private ListView lstProduct;

    public Color ButtonColor => GlobalMob.MenuColor;

    public Color TextColor => Color.White;

    public ProductList()
    {
      this.InitializeComponent();
      ((Page) this).Title = "Ürünler";
      this.MasterPage = GlobalMob.currentPage;
      if (!string.IsNullOrEmpty(((InputView) this.Product_Search).Text))
        ((InputView) this.Product_Search).Text = "";
      this.FillSearchPicker();
      this.FillProductList("");
    }

    protected virtual void OnAppearing()
    {
      ((Page) this).OnAppearing();
      ((NavigationPage) Application.Current.MainPage).BarBackgroundColor = GlobalMob.MenuColor;
    }

    private void LstProduct_ItemSelected(object sender, SelectedItemChangedEventArgs e)
    {
      object selectedItem = ((ListView) sender).SelectedItem;
      if (selectedItem == null)
        return;
      this.selectedItem = (pIOGetShelfItemsReturnModel) selectedItem;
      if (this.IsClose)
        ((NavigableElement) this).Navigation.PopAsync();
      this.lstProduct.SelectedItem = (object) null;
      if (this.ProductSelectedItem == null)
        return;
      this.ProductSelectedItem((object) this, (EventArgs) e);
    }

    private void PckSearch_SelectedIndexChanged(object sender, EventArgs e)
    {
      PickerItem selectedItem = (PickerItem) this.pckSearch.SelectedItem;
      if (selectedItem == null)
        return;
      ((InputView) this.Product_Search).Placeholder = selectedItem.Description;
      Settings.ProductSearchType = Convert.ToString(selectedItem.Code);
    }

    private void FillSearchPicker()
    {
      this.pckSearch.ItemsSource = (IList) new List<PickerItem>()
      {
        new PickerItem()
        {
          Caption = "M",
          Code = 1,
          Description = "Ürün kodu giriniz"
        },
        new PickerItem()
        {
          Caption = "B",
          Code = 2,
          Description = "Barkod okutunuz"
        }
      };
      if (!string.IsNullOrEmpty(Settings.ProductSearchType))
        this.pckSearch.SelectedIndex = Convert.ToInt32(Settings.ProductSearchType) - 1;
      else
        this.pckSearch.SelectedIndex = 0;
    }

    private void FillProductList(string text)
    {
      if (string.IsNullOrEmpty(text))
        return;
      string str = "";
      PickerItem selectedItem = (PickerItem) this.pckSearch.SelectedItem;
      if (selectedItem != null)
        str = Convert.ToString(selectedItem.Code);
      int num = 0;
      if (GlobalMob.CurrentMenuItem != null)
        num = GlobalMob.CurrentMenuItem.MenuId;
      ReturnModel returnModel = GlobalMob.PostJson(string.Format("GetItems?itemCode={0}&type={1}&menuID={2}", (object) text, (object) str, (object) num), this.MasterPage);
      List<pIOGetShelfItemsReturnModel> itemsReturnModelList1 = new List<pIOGetShelfItemsReturnModel>();
      if (!returnModel.Success)
        return;
      List<pIOGetShelfItemsReturnModel> itemsReturnModelList2 = GlobalMob.JsonDeserialize<List<pIOGetShelfItemsReturnModel>>(returnModel.Result);
      bool flag = false;
      if (itemsReturnModelList2 == null || itemsReturnModelList2.Count == 0)
        flag = true;
      ((VisualElement) this.stckProductMessage).IsVisible = flag;
      ((BindableObject) this.lstProduct).BindingContext = (object) itemsReturnModelList2;
    }

    public void FocusSearch() => Device.BeginInvokeOnMainThread((Action) (async () =>
    {
      await Task.Delay(300);
      ((VisualElement) this.Product_Search)?.Focus();
    }));

    public event EventHandler ProductSelectedItem;

    private void Product_Search_TextChanged(object sender, TextChangedEventArgs e)
    {
      try
      {
        string text = ((InputView) this.Product_Search).Text;
        PickerItem selectedItem = (PickerItem) this.pckSearch.SelectedItem;
        if (selectedItem != null && selectedItem.Code == 1)
          this.FillProductList(text);
        if (selectedItem != null && selectedItem.Code == 2 && !string.IsNullOrEmpty(text) && string.IsNullOrEmpty(Convert.ToString(text[text.Length - 1])))
          this.FillProductList(text.Trim().Replace(" ", ""));
        this.FocusSearch();
      }
      catch (Exception ex)
      {
      }
    }

    private void Product_Search_Completed(object sender, EventArgs e)
    {
      this.FillProductList(((InputView) this.Product_Search).Text);
      this.FocusSearch();
    }

    private void btnSearch_Clicked(object sender, EventArgs e) => this.Product_Search_Completed((object) null, (EventArgs) null);

    private void btnClear_Clicked(object sender, EventArgs e)
    {
      ((InputView) this.Product_Search).Text = "";
      this.Product_Search_Completed((object) null, (EventArgs) null);
    }

    [GeneratedCode("Xamarin.Forms.Build.Tasks.XamlG", "2.0.0.0")]
    private void InitializeComponent()
    {
      if (ResourceLoader.CanProvideContentFor(new ResourceLoader.ResourceLoadingQuery()
      {
        AssemblyName = typeof (ProductList).GetTypeInfo().Assembly.GetName(),
        ResourcePath = "Controls/ProductList.xaml",
        Instance = (object) this
      }))
        this.__InitComponentRuntime();
      else if (XamlLoader.XamlFileProvider != null && XamlLoader.XamlFileProvider(((object) this).GetType()) != null)
      {
        this.__InitComponentRuntime();
      }
      else
      {
        Label label1 = new Label();
        StackLayout stackLayout1 = new StackLayout();
        Xamarin.Forms.Entry entry = new Xamarin.Forms.Entry();
        BindingExtension bindingExtension1 = new BindingExtension();
        BindingExtension bindingExtension2 = new BindingExtension();
        Picker picker = new Picker();
        ReferenceExtension referenceExtension1 = new ReferenceExtension();
        BindingExtension bindingExtension3 = new BindingExtension();
        ImageButton imageButton = new ImageButton();
        ReferenceExtension referenceExtension2 = new ReferenceExtension();
        BindingExtension bindingExtension4 = new BindingExtension();
        Button button1 = new Button();
        StackLayout stackLayout2 = new StackLayout();
        BindingExtension bindingExtension5 = new BindingExtension();
        DataTemplate dataTemplate1 = new DataTemplate();
        ListView listView = new ListView();
        StackLayout stackLayout3 = new StackLayout();
        ProductList productList;
        NameScope nameScope = (NameScope) (NameScope.GetNameScope((BindableObject) (productList = this)) ?? (INameScope) new NameScope());
        NameScope.SetNameScope((BindableObject) productList, (INameScope) nameScope);
        ((INameScope) nameScope).RegisterName("product", (object) productList);
        if (((Element) productList).StyleId == null)
          ((Element) productList).StyleId = "product";
        ((INameScope) nameScope).RegisterName("stckProductList", (object) stackLayout3);
        if (((Element) stackLayout3).StyleId == null)
          ((Element) stackLayout3).StyleId = "stckProductList";
        ((INameScope) nameScope).RegisterName("stckProductMessage", (object) stackLayout1);
        if (((Element) stackLayout1).StyleId == null)
          ((Element) stackLayout1).StyleId = "stckProductMessage";
        ((INameScope) nameScope).RegisterName("stckSearch", (object) stackLayout2);
        if (((Element) stackLayout2).StyleId == null)
          ((Element) stackLayout2).StyleId = "stckSearch";
        ((INameScope) nameScope).RegisterName("Product_Search", (object) entry);
        if (((Element) entry).StyleId == null)
          ((Element) entry).StyleId = "Product_Search";
        ((INameScope) nameScope).RegisterName("pckSearch", (object) picker);
        if (((Element) picker).StyleId == null)
          ((Element) picker).StyleId = "pckSearch";
        ((INameScope) nameScope).RegisterName("imgSearch", (object) imageButton);
        if (((Element) imageButton).StyleId == null)
          ((Element) imageButton).StyleId = "imgSearch";
        ((INameScope) nameScope).RegisterName("btnClear", (object) button1);
        if (((Element) button1).StyleId == null)
          ((Element) button1).StyleId = "btnClear";
        ((INameScope) nameScope).RegisterName("lstProduct", (object) listView);
        if (((Element) listView).StyleId == null)
          ((Element) listView).StyleId = "lstProduct";
        this.product = (ContentPage) productList;
        this.stckProductList = stackLayout3;
        this.stckProductMessage = stackLayout1;
        this.stckSearch = stackLayout2;
        this.Product_Search = entry;
        this.pckSearch = picker;
        this.imgSearch = imageButton;
        this.btnClear = button1;
        this.lstProduct = listView;
        ((BindableObject) stackLayout3).SetValue(StackLayout.OrientationProperty, (object) (StackOrientation) 0);
        ((BindableObject) stackLayout3).SetValue(View.VerticalOptionsProperty, (object) LayoutOptions.FillAndExpand);
        ((BindableObject) stackLayout1).SetValue(StackLayout.OrientationProperty, (object) (StackOrientation) 0);
        ((BindableObject) stackLayout1).SetValue(VisualElement.IsVisibleProperty, new VisualElement.VisibilityConverter().ConvertFromInvariantString("False"));
        ((BindableObject) stackLayout1).SetValue(View.VerticalOptionsProperty, (object) LayoutOptions.Center);
        ((BindableObject) stackLayout1).SetValue(View.HorizontalOptionsProperty, (object) LayoutOptions.Center);
        ((BindableObject) label1).SetValue(Label.TextProperty, (object) "Ürün Bulunamadı");
        ((BindableObject) label1).SetValue(View.VerticalOptionsProperty, (object) LayoutOptions.CenterAndExpand);
        ((BindableObject) label1).SetValue(Label.FontAttributesProperty, new FontAttributesConverter().ConvertFromInvariantString("Bold"));
        Label label2 = label1;
        BindableProperty fontSizeProperty1 = Label.FontSizeProperty;
        FontSizeConverter fontSizeConverter1 = new FontSizeConverter();
        XamlServiceProvider xamlServiceProvider1 = new XamlServiceProvider();
        Type type1 = typeof (IProvideValueTarget);
        object[] objArray1 = new object[0 + 4];
        objArray1[0] = (object) label1;
        objArray1[1] = (object) stackLayout1;
        objArray1[2] = (object) stackLayout3;
        objArray1[3] = (object) productList;
        SimpleValueTargetProvider valueTargetProvider1;
        object obj1 = (object) (valueTargetProvider1 = new SimpleValueTargetProvider(objArray1, (object) Label.FontSizeProperty, (INameScope) nameScope));
        xamlServiceProvider1.Add(type1, (object) valueTargetProvider1);
        xamlServiceProvider1.Add(typeof (IReferenceProvider), obj1);
        Type type2 = typeof (IXamlTypeResolver);
        XmlNamespaceResolver namespaceResolver1 = new XmlNamespaceResolver();
        namespaceResolver1.Add("", "http://xamarin.com/schemas/2014/forms");
        namespaceResolver1.Add("x", "http://schemas.microsoft.com/winfx/2009/xaml");
        XamlTypeResolver xamlTypeResolver1 = new XamlTypeResolver((IXmlNamespaceResolver) namespaceResolver1, typeof (ProductList).GetTypeInfo().Assembly);
        xamlServiceProvider1.Add(type2, (object) xamlTypeResolver1);
        xamlServiceProvider1.Add(typeof (IXmlLineInfoProvider), (object) new XmlLineInfoProvider((IXmlLineInfo) new XmlLineInfo(9, 105)));
        object obj2 = ((IExtendedTypeConverter) fontSizeConverter1).ConvertFromInvariantString("Medium", (IServiceProvider) xamlServiceProvider1);
        ((BindableObject) label2).SetValue(fontSizeProperty1, obj2);
        ((ICollection<View>) ((Layout<View>) stackLayout1).Children).Add((View) label1);
        VisualDiagnostics.RegisterSourceInfo((object) label1, new Uri("Controls\\ProductList.xaml" + ";assembly=" + "Shelf", UriKind.RelativeOrAbsolute), 9, 18);
        ((ICollection<View>) ((Layout<View>) stackLayout3).Children).Add((View) stackLayout1);
        VisualDiagnostics.RegisterSourceInfo((object) stackLayout1, new Uri("Controls\\ProductList.xaml" + ";assembly=" + "Shelf", UriKind.RelativeOrAbsolute), 8, 14);
        ((BindableObject) stackLayout2).SetValue(StackLayout.OrientationProperty, (object) (StackOrientation) 1);
        ((BindableObject) stackLayout2).SetValue(View.MarginProperty, (object) new Thickness(5.0));
        ((BindableObject) entry).SetValue(Xamarin.Forms.Entry.PlaceholderProperty, (object) "Ürün Kodu Ara");
        entry.Completed += new EventHandler(productList.Product_Search_Completed);
        ((BindableObject) entry).SetValue(View.HorizontalOptionsProperty, (object) LayoutOptions.FillAndExpand);
        ((ICollection<View>) ((Layout<View>) stackLayout2).Children).Add((View) entry);
        VisualDiagnostics.RegisterSourceInfo((object) entry, new Uri("Controls\\ProductList.xaml" + ";assembly=" + "Shelf", UriKind.RelativeOrAbsolute), 12, 18);
        ((BindableObject) picker).SetValue(Picker.TitleProperty, (object) "Arama Tipi");
        bindingExtension1.Path = ".";
        BindingBase bindingBase1 = ((IMarkupExtension<BindingBase>) bindingExtension1).ProvideValue((IServiceProvider) null);
        ((BindableObject) picker).SetBinding(Picker.ItemsSourceProperty, bindingBase1);
        ((BindableObject) picker).SetValue(View.HorizontalOptionsProperty, (object) LayoutOptions.End);
        ((BindableObject) picker).SetValue(VisualElement.WidthRequestProperty, (object) 50.0);
        bindingExtension2.Path = "Caption";
        BindingBase bindingBase2 = ((IMarkupExtension<BindingBase>) bindingExtension2).ProvideValue((IServiceProvider) null);
        picker.ItemDisplayBinding = bindingBase2;
        VisualDiagnostics.RegisterSourceInfo((object) bindingBase2, new Uri("Controls\\ProductList.xaml" + ";assembly=" + "Shelf", UriKind.RelativeOrAbsolute), 15, 29);
        picker.SelectedIndexChanged += new EventHandler(productList.PckSearch_SelectedIndexChanged);
        ((ICollection<View>) ((Layout<View>) stackLayout2).Children).Add((View) picker);
        VisualDiagnostics.RegisterSourceInfo((object) picker, new Uri("Controls\\ProductList.xaml" + ";assembly=" + "Shelf", UriKind.RelativeOrAbsolute), 14, 18);
        ((BindableObject) imageButton).SetValue(ImageButton.SourceProperty, new ImageSourceConverter().ConvertFromInvariantString("search.png"));
        referenceExtension1.Name = "product";
        ReferenceExtension referenceExtension3 = referenceExtension1;
        XamlServiceProvider xamlServiceProvider2 = new XamlServiceProvider();
        Type type3 = typeof (IProvideValueTarget);
        object[] objArray2 = new object[0 + 5];
        objArray2[0] = (object) bindingExtension3;
        objArray2[1] = (object) imageButton;
        objArray2[2] = (object) stackLayout2;
        objArray2[3] = (object) stackLayout3;
        objArray2[4] = (object) productList;
        SimpleValueTargetProvider valueTargetProvider2;
        object obj3 = (object) (valueTargetProvider2 = new SimpleValueTargetProvider(objArray2, (object) typeof (BindingExtension).GetRuntimeProperty("Source"), (INameScope) nameScope));
        xamlServiceProvider2.Add(type3, (object) valueTargetProvider2);
        xamlServiceProvider2.Add(typeof (IReferenceProvider), obj3);
        Type type4 = typeof (IXamlTypeResolver);
        XmlNamespaceResolver namespaceResolver2 = new XmlNamespaceResolver();
        namespaceResolver2.Add("", "http://xamarin.com/schemas/2014/forms");
        namespaceResolver2.Add("x", "http://schemas.microsoft.com/winfx/2009/xaml");
        XamlTypeResolver xamlTypeResolver2 = new XamlTypeResolver((IXmlNamespaceResolver) namespaceResolver2, typeof (ProductList).GetTypeInfo().Assembly);
        xamlServiceProvider2.Add(type4, (object) xamlTypeResolver2);
        xamlServiceProvider2.Add(typeof (IXmlLineInfoProvider), (object) new XmlLineInfoProvider((IXmlLineInfo) new XmlLineInfo(16, 69)));
        object obj4 = ((IMarkupExtension) referenceExtension3).ProvideValue((IServiceProvider) xamlServiceProvider2);
        bindingExtension3.Source = obj4;
        VisualDiagnostics.RegisterSourceInfo(obj4, new Uri("Controls\\ProductList.xaml" + ";assembly=" + "Shelf", UriKind.RelativeOrAbsolute), 16, 69);
        bindingExtension3.Path = "ButtonColor";
        BindingBase bindingBase3 = ((IMarkupExtension<BindingBase>) bindingExtension3).ProvideValue((IServiceProvider) null);
        ((BindableObject) imageButton).SetBinding(VisualElement.BackgroundColorProperty, bindingBase3);
        ((BindableObject) imageButton).SetValue(ImageButton.AspectProperty, (object) (Aspect) 0);
        ((BindableObject) imageButton).SetValue(VisualElement.WidthRequestProperty, (object) 40.0);
        ((BindableObject) imageButton).SetValue(VisualElement.HeightRequestProperty, (object) 40.0);
        ((BindableObject) imageButton).SetValue(View.HorizontalOptionsProperty, (object) LayoutOptions.End);
        imageButton.Clicked += new EventHandler(productList.btnSearch_Clicked);
        ((ICollection<View>) ((Layout<View>) stackLayout2).Children).Add((View) imageButton);
        VisualDiagnostics.RegisterSourceInfo((object) imageButton, new Uri("Controls\\ProductList.xaml" + ";assembly=" + "Shelf", UriKind.RelativeOrAbsolute), 16, 18);
        button1.Clicked += new EventHandler(productList.btnClear_Clicked);
        referenceExtension2.Name = "product";
        ReferenceExtension referenceExtension4 = referenceExtension2;
        XamlServiceProvider xamlServiceProvider3 = new XamlServiceProvider();
        Type type5 = typeof (IProvideValueTarget);
        object[] objArray3 = new object[0 + 5];
        objArray3[0] = (object) bindingExtension4;
        objArray3[1] = (object) button1;
        objArray3[2] = (object) stackLayout2;
        objArray3[3] = (object) stackLayout3;
        objArray3[4] = (object) productList;
        SimpleValueTargetProvider valueTargetProvider3;
        object obj5 = (object) (valueTargetProvider3 = new SimpleValueTargetProvider(objArray3, (object) typeof (BindingExtension).GetRuntimeProperty("Source"), (INameScope) nameScope));
        xamlServiceProvider3.Add(type5, (object) valueTargetProvider3);
        xamlServiceProvider3.Add(typeof (IReferenceProvider), obj5);
        Type type6 = typeof (IXamlTypeResolver);
        XmlNamespaceResolver namespaceResolver3 = new XmlNamespaceResolver();
        namespaceResolver3.Add("", "http://xamarin.com/schemas/2014/forms");
        namespaceResolver3.Add("x", "http://schemas.microsoft.com/winfx/2009/xaml");
        XamlTypeResolver xamlTypeResolver3 = new XamlTypeResolver((IXmlNamespaceResolver) namespaceResolver3, typeof (ProductList).GetTypeInfo().Assembly);
        xamlServiceProvider3.Add(type6, (object) xamlTypeResolver3);
        xamlServiceProvider3.Add(typeof (IXmlLineInfoProvider), (object) new XmlLineInfoProvider((IXmlLineInfo) new XmlLineInfo(19, 71)));
        object obj6 = ((IMarkupExtension) referenceExtension4).ProvideValue((IServiceProvider) xamlServiceProvider3);
        bindingExtension4.Source = obj6;
        VisualDiagnostics.RegisterSourceInfo(obj6, new Uri("Controls\\ProductList.xaml" + ";assembly=" + "Shelf", UriKind.RelativeOrAbsolute), 19, 71);
        bindingExtension4.Path = "ButtonColor";
        BindingBase bindingBase4 = ((IMarkupExtension<BindingBase>) bindingExtension4).ProvideValue((IServiceProvider) null);
        ((BindableObject) button1).SetBinding(VisualElement.BackgroundColorProperty, bindingBase4);
        ((BindableObject) button1).SetValue(Button.FontAttributesProperty, new FontAttributesConverter().ConvertFromInvariantString("Bold"));
        ((BindableObject) button1).SetValue(Button.TextProperty, (object) "X");
        ((BindableObject) button1).SetValue(VisualElement.HeightRequestProperty, (object) 40.0);
        Button button2 = button1;
        BindableProperty fontSizeProperty2 = Button.FontSizeProperty;
        FontSizeConverter fontSizeConverter2 = new FontSizeConverter();
        XamlServiceProvider xamlServiceProvider4 = new XamlServiceProvider();
        Type type7 = typeof (IProvideValueTarget);
        object[] objArray4 = new object[0 + 4];
        objArray4[0] = (object) button1;
        objArray4[1] = (object) stackLayout2;
        objArray4[2] = (object) stackLayout3;
        objArray4[3] = (object) productList;
        SimpleValueTargetProvider valueTargetProvider4;
        object obj7 = (object) (valueTargetProvider4 = new SimpleValueTargetProvider(objArray4, (object) Button.FontSizeProperty, (INameScope) nameScope));
        xamlServiceProvider4.Add(type7, (object) valueTargetProvider4);
        xamlServiceProvider4.Add(typeof (IReferenceProvider), obj7);
        Type type8 = typeof (IXamlTypeResolver);
        XmlNamespaceResolver namespaceResolver4 = new XmlNamespaceResolver();
        namespaceResolver4.Add("", "http://xamarin.com/schemas/2014/forms");
        namespaceResolver4.Add("x", "http://schemas.microsoft.com/winfx/2009/xaml");
        XamlTypeResolver xamlTypeResolver4 = new XamlTypeResolver((IXmlNamespaceResolver) namespaceResolver4, typeof (ProductList).GetTypeInfo().Assembly);
        xamlServiceProvider4.Add(type8, (object) xamlTypeResolver4);
        xamlServiceProvider4.Add(typeof (IXmlLineInfoProvider), (object) new XmlLineInfoProvider((IXmlLineInfo) new XmlLineInfo(20, 75)));
        object obj8 = ((IExtendedTypeConverter) fontSizeConverter2).ConvertFromInvariantString("Large", (IServiceProvider) xamlServiceProvider4);
        ((BindableObject) button2).SetValue(fontSizeProperty2, obj8);
        ((BindableObject) button1).SetValue(VisualElement.WidthRequestProperty, (object) 40.0);
        ((BindableObject) button1).SetValue(Button.TextColorProperty, (object) Color.White);
        ((BindableObject) button1).SetValue(View.HorizontalOptionsProperty, (object) LayoutOptions.End);
        ((ICollection<View>) ((Layout<View>) stackLayout2).Children).Add((View) button1);
        VisualDiagnostics.RegisterSourceInfo((object) button1, new Uri("Controls\\ProductList.xaml" + ";assembly=" + "Shelf", UriKind.RelativeOrAbsolute), 19, 18);
        ((ICollection<View>) ((Layout<View>) stackLayout3).Children).Add((View) stackLayout2);
        VisualDiagnostics.RegisterSourceInfo((object) stackLayout2, new Uri("Controls\\ProductList.xaml" + ";assembly=" + "Shelf", UriKind.RelativeOrAbsolute), 11, 14);
        bindingExtension5.Path = ".";
        BindingBase bindingBase5 = ((IMarkupExtension<BindingBase>) bindingExtension5).ProvideValue((IServiceProvider) null);
        ((BindableObject) listView).SetBinding(ItemsView<Cell>.ItemsSourceProperty, bindingBase5);
        ((BindableObject) listView).SetValue(ListView.HasUnevenRowsProperty, (object) true);
        listView.ItemSelected += new EventHandler<SelectedItemChangedEventArgs>(productList.LstProduct_ItemSelected);
        DataTemplate dataTemplate2 = dataTemplate1;
        // ISSUE: object of a compiler-generated type is created
        // ISSUE: variable of a compiler-generated type
        ProductList.\u003CInitializeComponent\u003E_anonXamlCDataTemplate_0 xamlCdataTemplate0 = new ProductList.\u003CInitializeComponent\u003E_anonXamlCDataTemplate_0();
        object[] objArray5 = new object[0 + 4];
        objArray5[0] = (object) dataTemplate1;
        objArray5[1] = (object) listView;
        objArray5[2] = (object) stackLayout3;
        objArray5[3] = (object) productList;
        // ISSUE: reference to a compiler-generated field
        xamlCdataTemplate0.parentValues = objArray5;
        // ISSUE: reference to a compiler-generated field
        xamlCdataTemplate0.root = productList;
        // ISSUE: reference to a compiler-generated method
        Func<object> func = new Func<object>(xamlCdataTemplate0.LoadDataTemplate);
        ((IDataTemplate) dataTemplate2).LoadTemplate = func;
        ((BindableObject) listView).SetValue(ItemsView<Cell>.ItemTemplateProperty, (object) dataTemplate1);
        VisualDiagnostics.RegisterSourceInfo((object) dataTemplate1, new Uri("Controls\\ProductList.xaml" + ";assembly=" + "Shelf", UriKind.RelativeOrAbsolute), 24, 22);
        ((ICollection<View>) ((Layout<View>) stackLayout3).Children).Add((View) listView);
        VisualDiagnostics.RegisterSourceInfo((object) listView, new Uri("Controls\\ProductList.xaml" + ";assembly=" + "Shelf", UriKind.RelativeOrAbsolute), 22, 14);
        ((BindableObject) productList).SetValue(ContentPage.ContentProperty, (object) stackLayout3);
        VisualDiagnostics.RegisterSourceInfo((object) stackLayout3, new Uri("Controls\\ProductList.xaml" + ";assembly=" + "Shelf", UriKind.RelativeOrAbsolute), 7, 10);
        VisualDiagnostics.RegisterSourceInfo((object) productList, new Uri("Controls\\ProductList.xaml" + ";assembly=" + "Shelf", UriKind.RelativeOrAbsolute), 2, 2);
      }
    }

    private void __InitComponentRuntime()
    {
      Extensions.LoadFromXaml<ProductList>(this, typeof (ProductList));
      this.product = NameScopeExtensions.FindByName<ContentPage>((Element) this, "product");
      this.stckProductList = NameScopeExtensions.FindByName<StackLayout>((Element) this, "stckProductList");
      this.stckProductMessage = NameScopeExtensions.FindByName<StackLayout>((Element) this, "stckProductMessage");
      this.stckSearch = NameScopeExtensions.FindByName<StackLayout>((Element) this, "stckSearch");
      this.Product_Search = NameScopeExtensions.FindByName<Xamarin.Forms.Entry>((Element) this, "Product_Search");
      this.pckSearch = NameScopeExtensions.FindByName<Picker>((Element) this, "pckSearch");
      this.imgSearch = NameScopeExtensions.FindByName<ImageButton>((Element) this, "imgSearch");
      this.btnClear = NameScopeExtensions.FindByName<Button>((Element) this, "btnClear");
      this.lstProduct = NameScopeExtensions.FindByName<ListView>((Element) this, "lstProduct");
    }
  }
}
