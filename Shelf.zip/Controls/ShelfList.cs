﻿// Decompiled with JetBrains decompiler
// Type: Shelf.Controls.ShelfList
// Assembly: Shelf, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 34392FE8-51B4-4368-914A-8B6FB98A7971
// Assembly location: C:\Users\pc\reverse_engineering\com.companyname.Shelf\assemblies\Shelf.dll

using Rg.Plugins.Popup.Extensions;
using Shelf.Manager;
using Shelf.Models;
using Shelf.Views;
using System;
using System.CodeDom.Compiler;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using System.Threading.Tasks;
using System.Xml;
using Xamarin.Forms;
using Xamarin.Forms.Internals;
using Xamarin.Forms.Xaml;
using Xamarin.Forms.Xaml.Diagnostics;
using Xamarin.Forms.Xaml.Internals;

namespace Shelf.Controls
{
  [XamlCompilation]
  [XamlFilePath("Controls\\ShelfList.xaml")]
  public class ShelfList : ContentPage
  {
    private List<pIOGetShelfFromTextReturnModel> list;
    public pIOGetShelfFromTextReturnModel selectedShelf;
    [GeneratedCode("Xamarin.Forms.Build.Tasks.XamlG", "2.0.0.0")]
    private StackLayout stckSearch;
    [GeneratedCode("Xamarin.Forms.Build.Tasks.XamlG", "2.0.0.0")]
    private Xamarin.Forms.Entry txtSearch;
    [GeneratedCode("Xamarin.Forms.Build.Tasks.XamlG", "2.0.0.0")]
    private ImageButton imgSearch;
    [GeneratedCode("Xamarin.Forms.Build.Tasks.XamlG", "2.0.0.0")]
    private Button btnClear;
    [GeneratedCode("Xamarin.Forms.Build.Tasks.XamlG", "2.0.0.0")]
    private StackLayout stckShelfList;
    [GeneratedCode("Xamarin.Forms.Build.Tasks.XamlG", "2.0.0.0")]
    private StackLayout stckEmptyMessage;
    [GeneratedCode("Xamarin.Forms.Build.Tasks.XamlG", "2.0.0.0")]
    private ListView lstShelf;

    public event EventHandler ShelfSelectedItem;

    public ShelfList(string searchText = "")
    {
      this.InitializeComponent();
      ((Page) this).Title = "Raf Ara";
      this.lstShelf.ItemSelected += new EventHandler<SelectedItemChangedEventArgs>(this.LstShelf_ItemSelected);
      ((VisualElement) this.imgSearch).BackgroundColor = GlobalMob.MenuColor;
      ((VisualElement) this.btnClear).BackgroundColor = GlobalMob.MenuColor;
      this.selectedShelf = (pIOGetShelfFromTextReturnModel) null;
      if (!string.IsNullOrEmpty(searchText))
      {
        ((InputView) this.txtSearch).Text = searchText;
        this.txtSearch_Completed((object) this.txtSearch, (EventArgs) null);
      }
      else
        this.BarcodeFocus();
    }

    private void BarcodeFocus() => Device.BeginInvokeOnMainThread((Action) (async () =>
    {
      await Task.Delay(250);
      ((VisualElement) this.txtSearch)?.Focus();
    }));

    private void LstShelf_ItemSelected(object sender, SelectedItemChangedEventArgs e)
    {
      this.selectedShelf = (pIOGetShelfFromTextReturnModel) e.SelectedItem;
      ((NavigableElement) this).Navigation.PopAsync();
      if (this.ShelfSelectedItem == null)
        return;
      this.ShelfSelectedItem((object) this, (EventArgs) e);
    }

    private async void LoadData()
    {
      ShelfList page = this;
      await NavigationExtension.PushPopupAsync(((NavigableElement) page).Navigation, GlobalMob.ShowLoading(), true);
      ReturnModel returnModel = GlobalMob.PostJson(string.Format("GetShelfFromText?searchText={0}", (object) ((InputView) page.txtSearch).Text), (ContentPage) page);
      if (returnModel.Success)
      {
        page.list = GlobalMob.JsonDeserialize<List<pIOGetShelfFromTextReturnModel>>(returnModel.Result);
        page.RefreshData();
      }
      GlobalMob.CloseLoading();
    }

    private void RefreshData()
    {
      bool flag = false;
      if (this.list == null || this.list.Count == 0)
        flag = true;
      ((VisualElement) this.stckEmptyMessage).IsVisible = flag;
      ((BindableObject) this.lstShelf).BindingContext = (object) this.list;
    }

    private void txtSearch_Completed(object sender, EventArgs e) => this.LoadData();

    private void imgSearch_Clicked(object sender, EventArgs e) => this.LoadData();

    private void btnClear_Clicked(object sender, EventArgs e)
    {
      ((InputView) this.txtSearch).Text = "";
      this.selectedShelf = (pIOGetShelfFromTextReturnModel) null;
      this.list = new List<pIOGetShelfFromTextReturnModel>();
      this.RefreshData();
      this.BarcodeFocus();
    }

    private async void cmShelfInventory_Clicked(object sender, EventArgs e)
    {
      ShelfList page = this;
      await NavigationExtension.PushPopupAsync(((NavigableElement) page).Navigation, GlobalMob.ShowLoading(), true);
      pIOGetShelfFromTextReturnModel commandParameter = (pIOGetShelfFromTextReturnModel) (sender as MenuItem).CommandParameter;
      if (commandParameter == null)
        return;
      ReturnModel returnModel = GlobalMob.PostJson(string.Format("GetInventoryFromShelfID?shelfID={0}", (object) commandParameter.ShelfID), (ContentPage) page);
      if (returnModel.Success)
      {
        List<pIOGetInventoryFromShelfIDReturnModel> shelfIdReturnModelList = GlobalMob.JsonDeserialize<List<pIOGetInventoryFromShelfIDReturnModel>>(returnModel.Result);
        ListView shelfListview = GlobalMob.GetShelfListview("ItemCodeLong,InventoryQty");
        ((ItemsView<Cell>) shelfListview).ItemsSource = (IEnumerable) shelfIdReturnModelList;
        SelectItem selectItem = new SelectItem(shelfListview, commandParameter.Code + "- Envanteri");
        await ((NavigableElement) page).Navigation.PushAsync((Page) selectItem);
      }
      GlobalMob.CloseLoading();
    }

    private async void cmShelfPrint_Clicked(object sender, EventArgs e)
    {
      ShelfList page = this;
      pIOGetShelfFromTextReturnModel item = (pIOGetShelfFromTextReturnModel) (sender as MenuItem).CommandParameter;
      if (string.IsNullOrEmpty(item.FileName))
      {
        int num = await ((Page) page).DisplayAlert("Uyarı", "Raf barkodu için template eklenmemiş", "", "Tamam") ? 1 : 0;
        item = (pIOGetShelfFromTextReturnModel) null;
      }
      else
      {
        await NavigationExtension.PushPopupAsync(((NavigableElement) page).Navigation, GlobalMob.ShowLoading(), true);
        int num = item.FileName.Contains(".repx") ? 2 : 1;
        List<BLReport> repList = new List<BLReport>();
        BLReport blReport = new BLReport()
        {
          ReportTypeID = 4,
          UserID = GlobalMob.User.UserID,
          FileType = num,
          PrinterBrandID = Convert.ToInt32((object) item.PrinterBrandID),
          NetworkPrinter = item.NetworkPrinter
        };
        blReport.ParamList = new List<BLReportParam>();
        blReport.ParamList.Add(new BLReportParam()
        {
          ParamName = "ShelfCode",
          ParamValue = item.Code,
          ParamType = 20
        });
        repList.Add(blReport);
        GlobalMob.BLPrint(repList, (object) item, (ContentPage) page);
        GlobalMob.CloseLoading();
        item = (pIOGetShelfFromTextReturnModel) null;
      }
    }

    [GeneratedCode("Xamarin.Forms.Build.Tasks.XamlG", "2.0.0.0")]
    private void InitializeComponent()
    {
      if (ResourceLoader.CanProvideContentFor(new ResourceLoader.ResourceLoadingQuery()
      {
        AssemblyName = typeof (ShelfList).GetTypeInfo().Assembly.GetName(),
        ResourcePath = "Controls/ShelfList.xaml",
        Instance = (object) this
      }))
        this.__InitComponentRuntime();
      else if (XamlLoader.XamlFileProvider != null && XamlLoader.XamlFileProvider(((object) this).GetType()) != null)
      {
        this.__InitComponentRuntime();
      }
      else
      {
        Xamarin.Forms.Entry entry = new Xamarin.Forms.Entry();
        ImageButton imageButton = new ImageButton();
        Button button1 = new Button();
        StackLayout stackLayout1 = new StackLayout();
        Label label1 = new Label();
        StackLayout stackLayout2 = new StackLayout();
        BindingExtension bindingExtension = new BindingExtension();
        DataTemplate dataTemplate1 = new DataTemplate();
        ListView listView = new ListView();
        StackLayout stackLayout3 = new StackLayout();
        StackLayout stackLayout4 = new StackLayout();
        ShelfList shelfList;
        NameScope nameScope = (NameScope) (NameScope.GetNameScope((BindableObject) (shelfList = this)) ?? (INameScope) new NameScope());
        NameScope.SetNameScope((BindableObject) shelfList, (INameScope) nameScope);
        ((INameScope) nameScope).RegisterName("stckSearch", (object) stackLayout1);
        if (((Element) stackLayout1).StyleId == null)
          ((Element) stackLayout1).StyleId = "stckSearch";
        ((INameScope) nameScope).RegisterName("txtSearch", (object) entry);
        if (((Element) entry).StyleId == null)
          ((Element) entry).StyleId = "txtSearch";
        ((INameScope) nameScope).RegisterName("imgSearch", (object) imageButton);
        if (((Element) imageButton).StyleId == null)
          ((Element) imageButton).StyleId = "imgSearch";
        ((INameScope) nameScope).RegisterName("btnClear", (object) button1);
        if (((Element) button1).StyleId == null)
          ((Element) button1).StyleId = "btnClear";
        ((INameScope) nameScope).RegisterName("stckShelfList", (object) stackLayout3);
        if (((Element) stackLayout3).StyleId == null)
          ((Element) stackLayout3).StyleId = "stckShelfList";
        ((INameScope) nameScope).RegisterName("stckEmptyMessage", (object) stackLayout2);
        if (((Element) stackLayout2).StyleId == null)
          ((Element) stackLayout2).StyleId = "stckEmptyMessage";
        ((INameScope) nameScope).RegisterName("lstShelf", (object) listView);
        if (((Element) listView).StyleId == null)
          ((Element) listView).StyleId = "lstShelf";
        this.stckSearch = stackLayout1;
        this.txtSearch = entry;
        this.imgSearch = imageButton;
        this.btnClear = button1;
        this.stckShelfList = stackLayout3;
        this.stckEmptyMessage = stackLayout2;
        this.lstShelf = listView;
        ((BindableObject) stackLayout4).SetValue(View.MarginProperty, (object) new Thickness(5.0));
        ((BindableObject) stackLayout1).SetValue(StackLayout.OrientationProperty, (object) (StackOrientation) 1);
        ((BindableObject) entry).SetValue(Xamarin.Forms.Entry.PlaceholderProperty, (object) "Raf Ara");
        entry.Completed += new EventHandler(shelfList.txtSearch_Completed);
        ((BindableObject) entry).SetValue(View.HorizontalOptionsProperty, (object) LayoutOptions.FillAndExpand);
        ((ICollection<View>) ((Layout<View>) stackLayout1).Children).Add((View) entry);
        VisualDiagnostics.RegisterSourceInfo((object) entry, new Uri("Controls\\ShelfList.xaml" + ";assembly=" + "Shelf", UriKind.RelativeOrAbsolute), 11, 18);
        ((BindableObject) imageButton).SetValue(ImageButton.SourceProperty, new ImageSourceConverter().ConvertFromInvariantString("search.png"));
        ((BindableObject) imageButton).SetValue(ImageButton.AspectProperty, (object) (Aspect) 0);
        ((BindableObject) imageButton).SetValue(VisualElement.WidthRequestProperty, (object) 40.0);
        ((BindableObject) imageButton).SetValue(VisualElement.HeightRequestProperty, (object) 40.0);
        ((BindableObject) imageButton).SetValue(VisualElement.BackgroundColorProperty, (object) Color.White);
        ((BindableObject) imageButton).SetValue(View.HorizontalOptionsProperty, (object) LayoutOptions.End);
        imageButton.Clicked += new EventHandler(shelfList.imgSearch_Clicked);
        ((ICollection<View>) ((Layout<View>) stackLayout1).Children).Add((View) imageButton);
        VisualDiagnostics.RegisterSourceInfo((object) imageButton, new Uri("Controls\\ShelfList.xaml" + ";assembly=" + "Shelf", UriKind.RelativeOrAbsolute), 13, 18);
        button1.Clicked += new EventHandler(shelfList.btnClear_Clicked);
        ((BindableObject) button1).SetValue(Button.FontAttributesProperty, new FontAttributesConverter().ConvertFromInvariantString("Bold"));
        ((BindableObject) button1).SetValue(Button.TextProperty, (object) "X");
        ((BindableObject) button1).SetValue(VisualElement.HeightRequestProperty, (object) 40.0);
        Button button2 = button1;
        BindableProperty fontSizeProperty1 = Button.FontSizeProperty;
        FontSizeConverter fontSizeConverter1 = new FontSizeConverter();
        XamlServiceProvider xamlServiceProvider1 = new XamlServiceProvider();
        Type type1 = typeof (IProvideValueTarget);
        object[] objArray1 = new object[0 + 4];
        objArray1[0] = (object) button1;
        objArray1[1] = (object) stackLayout1;
        objArray1[2] = (object) stackLayout4;
        objArray1[3] = (object) shelfList;
        SimpleValueTargetProvider valueTargetProvider1;
        object obj1 = (object) (valueTargetProvider1 = new SimpleValueTargetProvider(objArray1, (object) Button.FontSizeProperty, (INameScope) nameScope));
        xamlServiceProvider1.Add(type1, (object) valueTargetProvider1);
        xamlServiceProvider1.Add(typeof (IReferenceProvider), obj1);
        Type type2 = typeof (IXamlTypeResolver);
        XmlNamespaceResolver namespaceResolver1 = new XmlNamespaceResolver();
        namespaceResolver1.Add("", "http://xamarin.com/schemas/2014/forms");
        namespaceResolver1.Add("x", "http://schemas.microsoft.com/winfx/2009/xaml");
        namespaceResolver1.Add("d", "http://xamarin.com/schemas/2014/forms/design");
        namespaceResolver1.Add("mc", "http://schemas.openxmlformats.org/markup-compatibility/2006");
        XamlTypeResolver xamlTypeResolver1 = new XamlTypeResolver((IXmlNamespaceResolver) namespaceResolver1, typeof (ShelfList).GetTypeInfo().Assembly);
        xamlServiceProvider1.Add(type2, (object) xamlTypeResolver1);
        xamlServiceProvider1.Add(typeof (IXmlLineInfoProvider), (object) new XmlLineInfoProvider((IXmlLineInfo) new XmlLineInfo(15, 120)));
        object obj2 = ((IExtendedTypeConverter) fontSizeConverter1).ConvertFromInvariantString("Large", (IServiceProvider) xamlServiceProvider1);
        ((BindableObject) button2).SetValue(fontSizeProperty1, obj2);
        ((BindableObject) button1).SetValue(VisualElement.WidthRequestProperty, (object) 40.0);
        ((BindableObject) button1).SetValue(Button.TextColorProperty, (object) Color.White);
        ((BindableObject) button1).SetValue(View.HorizontalOptionsProperty, (object) LayoutOptions.End);
        ((ICollection<View>) ((Layout<View>) stackLayout1).Children).Add((View) button1);
        VisualDiagnostics.RegisterSourceInfo((object) button1, new Uri("Controls\\ShelfList.xaml" + ";assembly=" + "Shelf", UriKind.RelativeOrAbsolute), 15, 18);
        ((ICollection<View>) ((Layout<View>) stackLayout4).Children).Add((View) stackLayout1);
        VisualDiagnostics.RegisterSourceInfo((object) stackLayout1, new Uri("Controls\\ShelfList.xaml" + ";assembly=" + "Shelf", UriKind.RelativeOrAbsolute), 10, 14);
        ((BindableObject) stackLayout3).SetValue(View.VerticalOptionsProperty, (object) LayoutOptions.FillAndExpand);
        ((BindableObject) stackLayout2).SetValue(StackLayout.OrientationProperty, (object) (StackOrientation) 0);
        ((BindableObject) stackLayout2).SetValue(VisualElement.IsVisibleProperty, new VisualElement.VisibilityConverter().ConvertFromInvariantString("False"));
        ((BindableObject) stackLayout2).SetValue(View.VerticalOptionsProperty, (object) LayoutOptions.Center);
        ((BindableObject) stackLayout2).SetValue(View.HorizontalOptionsProperty, (object) LayoutOptions.Center);
        ((BindableObject) label1).SetValue(Label.TextProperty, (object) "Raf Bulunamadı");
        ((BindableObject) label1).SetValue(View.VerticalOptionsProperty, (object) LayoutOptions.CenterAndExpand);
        ((BindableObject) label1).SetValue(Label.FontAttributesProperty, new FontAttributesConverter().ConvertFromInvariantString("Bold"));
        Label label2 = label1;
        BindableProperty fontSizeProperty2 = Label.FontSizeProperty;
        FontSizeConverter fontSizeConverter2 = new FontSizeConverter();
        XamlServiceProvider xamlServiceProvider2 = new XamlServiceProvider();
        Type type3 = typeof (IProvideValueTarget);
        object[] objArray2 = new object[0 + 5];
        objArray2[0] = (object) label1;
        objArray2[1] = (object) stackLayout2;
        objArray2[2] = (object) stackLayout3;
        objArray2[3] = (object) stackLayout4;
        objArray2[4] = (object) shelfList;
        SimpleValueTargetProvider valueTargetProvider2;
        object obj3 = (object) (valueTargetProvider2 = new SimpleValueTargetProvider(objArray2, (object) Label.FontSizeProperty, (INameScope) nameScope));
        xamlServiceProvider2.Add(type3, (object) valueTargetProvider2);
        xamlServiceProvider2.Add(typeof (IReferenceProvider), obj3);
        Type type4 = typeof (IXamlTypeResolver);
        XmlNamespaceResolver namespaceResolver2 = new XmlNamespaceResolver();
        namespaceResolver2.Add("", "http://xamarin.com/schemas/2014/forms");
        namespaceResolver2.Add("x", "http://schemas.microsoft.com/winfx/2009/xaml");
        namespaceResolver2.Add("d", "http://xamarin.com/schemas/2014/forms/design");
        namespaceResolver2.Add("mc", "http://schemas.openxmlformats.org/markup-compatibility/2006");
        XamlTypeResolver xamlTypeResolver2 = new XamlTypeResolver((IXmlNamespaceResolver) namespaceResolver2, typeof (ShelfList).GetTypeInfo().Assembly);
        xamlServiceProvider2.Add(type4, (object) xamlTypeResolver2);
        xamlServiceProvider2.Add(typeof (IXmlLineInfoProvider), (object) new XmlLineInfoProvider((IXmlLineInfo) new XmlLineInfo(20, 108)));
        object obj4 = ((IExtendedTypeConverter) fontSizeConverter2).ConvertFromInvariantString("Medium", (IServiceProvider) xamlServiceProvider2);
        ((BindableObject) label2).SetValue(fontSizeProperty2, obj4);
        ((ICollection<View>) ((Layout<View>) stackLayout2).Children).Add((View) label1);
        VisualDiagnostics.RegisterSourceInfo((object) label1, new Uri("Controls\\ShelfList.xaml" + ";assembly=" + "Shelf", UriKind.RelativeOrAbsolute), 20, 22);
        ((ICollection<View>) ((Layout<View>) stackLayout3).Children).Add((View) stackLayout2);
        VisualDiagnostics.RegisterSourceInfo((object) stackLayout2, new Uri("Controls\\ShelfList.xaml" + ";assembly=" + "Shelf", UriKind.RelativeOrAbsolute), 19, 18);
        bindingExtension.Path = ".";
        BindingBase bindingBase = ((IMarkupExtension<BindingBase>) bindingExtension).ProvideValue((IServiceProvider) null);
        ((BindableObject) listView).SetBinding(ItemsView<Cell>.ItemsSourceProperty, bindingBase);
        ((BindableObject) listView).SetValue(ListView.RowHeightProperty, (object) 60);
        ((BindableObject) listView).SetValue(ListView.SeparatorVisibilityProperty, (object) (SeparatorVisibility) 1);
        ((BindableObject) listView).SetValue(View.VerticalOptionsProperty, (object) LayoutOptions.FillAndExpand);
        DataTemplate dataTemplate2 = dataTemplate1;
        // ISSUE: object of a compiler-generated type is created
        // ISSUE: variable of a compiler-generated type
        ShelfList.\u003CInitializeComponent\u003E_anonXamlCDataTemplate_1 xamlCdataTemplate1 = new ShelfList.\u003CInitializeComponent\u003E_anonXamlCDataTemplate_1();
        object[] objArray3 = new object[0 + 5];
        objArray3[0] = (object) dataTemplate1;
        objArray3[1] = (object) listView;
        objArray3[2] = (object) stackLayout3;
        objArray3[3] = (object) stackLayout4;
        objArray3[4] = (object) shelfList;
        // ISSUE: reference to a compiler-generated field
        xamlCdataTemplate1.parentValues = objArray3;
        // ISSUE: reference to a compiler-generated field
        xamlCdataTemplate1.root = shelfList;
        // ISSUE: reference to a compiler-generated method
        Func<object> func = new Func<object>(xamlCdataTemplate1.LoadDataTemplate);
        ((IDataTemplate) dataTemplate2).LoadTemplate = func;
        ((BindableObject) listView).SetValue(ItemsView<Cell>.ItemTemplateProperty, (object) dataTemplate1);
        VisualDiagnostics.RegisterSourceInfo((object) dataTemplate1, new Uri("Controls\\ShelfList.xaml" + ";assembly=" + "Shelf", UriKind.RelativeOrAbsolute), 24, 26);
        ((ICollection<View>) ((Layout<View>) stackLayout3).Children).Add((View) listView);
        VisualDiagnostics.RegisterSourceInfo((object) listView, new Uri("Controls\\ShelfList.xaml" + ";assembly=" + "Shelf", UriKind.RelativeOrAbsolute), 22, 18);
        ((ICollection<View>) ((Layout<View>) stackLayout4).Children).Add((View) stackLayout3);
        VisualDiagnostics.RegisterSourceInfo((object) stackLayout3, new Uri("Controls\\ShelfList.xaml" + ";assembly=" + "Shelf", UriKind.RelativeOrAbsolute), 18, 14);
        ((BindableObject) shelfList).SetValue(ContentPage.ContentProperty, (object) stackLayout4);
        VisualDiagnostics.RegisterSourceInfo((object) stackLayout4, new Uri("Controls\\ShelfList.xaml" + ";assembly=" + "Shelf", UriKind.RelativeOrAbsolute), 9, 10);
        VisualDiagnostics.RegisterSourceInfo((object) shelfList, new Uri("Controls\\ShelfList.xaml" + ";assembly=" + "Shelf", UriKind.RelativeOrAbsolute), 2, 2);
      }
    }

    private void __InitComponentRuntime()
    {
      Xamarin.Forms.Xaml.Extensions.LoadFromXaml<ShelfList>(this, typeof (ShelfList));
      this.stckSearch = NameScopeExtensions.FindByName<StackLayout>((Element) this, "stckSearch");
      this.txtSearch = NameScopeExtensions.FindByName<Xamarin.Forms.Entry>((Element) this, "txtSearch");
      this.imgSearch = NameScopeExtensions.FindByName<ImageButton>((Element) this, "imgSearch");
      this.btnClear = NameScopeExtensions.FindByName<Button>((Element) this, "btnClear");
      this.stckShelfList = NameScopeExtensions.FindByName<StackLayout>((Element) this, "stckShelfList");
      this.stckEmptyMessage = NameScopeExtensions.FindByName<StackLayout>((Element) this, "stckEmptyMessage");
      this.lstShelf = NameScopeExtensions.FindByName<ListView>((Element) this, "lstShelf");
    }
  }
}
