﻿// Decompiled with JetBrains decompiler
// Type: Shelf.MainPage
// Assembly: Shelf, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 34392FE8-51B4-4368-914A-8B6FB98A7971
// Assembly location: C:\Users\pc\reverse_engineering\com.companyname.Shelf\assemblies\Shelf.dll

using Newtonsoft.Json;
using Shelf.Manager;
using Shelf.Models;
using Shelf.Views;
using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using Xamarin.Forms;
using Xamarin.Forms.Internals;
using Xamarin.Forms.Xaml;
using Xamarin.Forms.Xaml.Diagnostics;
using Xamarin.Forms.Xaml.Internals;

namespace Shelf
{
  [XamlCompilation]
  [XamlFilePath("Views\\MainPage.xaml")]
  public class MainPage : ContentPage
  {
    private List<MenuModelItem> menuList;
    private List<Label> CounterLabelList;
    private bool _canClose = true;
    private bool isClick;
    [GeneratedCode("Xamarin.Forms.Build.Tasks.XamlG", "2.0.0.0")]
    private ContentPage mainPage;
    [GeneratedCode("Xamarin.Forms.Build.Tasks.XamlG", "2.0.0.0")]
    private StackLayout picking;
    [GeneratedCode("Xamarin.Forms.Build.Tasks.XamlG", "2.0.0.0")]
    private StackLayout basket;
    [GeneratedCode("Xamarin.Forms.Build.Tasks.XamlG", "2.0.0.0")]
    private StackLayout shelfentry;

    public Color ButtonColor { get; set; }

    public Color TextColor => Color.White;

    public MainPage(List<MenuModelItem> fmenuList)
    {
      this.InitializeComponent();
      this.ButtonColor = Color.FromRgb(218, 18, 95);
      this.menuList = fmenuList;
      if (fmenuList.Where<MenuModelItem>((Func<MenuModelItem, bool>) (x => x.HeaderMenuID > 0)).Count<MenuModelItem>() != fmenuList.Count<MenuModelItem>())
        fmenuList = fmenuList.Where<MenuModelItem>((Func<MenuModelItem, bool>) (x => x.HeaderMenuID <= 0)).ToList<MenuModelItem>();
      ((VisualElement) this).BackgroundColor = Color.GhostWhite;
      ((Page) this).Title = "Raf Takip";
      if (fmenuList.Where<MenuModelItem>((Func<MenuModelItem, bool>) (x => x.HeaderMenuID <= 0)).Count<MenuModelItem>() > 0)
      {
        ToolbarItem toolbarItem = new ToolbarItem();
        ((MenuItem) toolbarItem).Text = GlobalMob.User.UserName;
        ((ICollection<ToolbarItem>) ((Page) this).ToolbarItems).Add(toolbarItem);
      }
      this.CounterLabelList = new List<Label>();
      if (GlobalMob.User != null)
      {
        if (string.IsNullOrEmpty(GlobalMob.User.MenuIds))
          GlobalMob.User.MenuIds = ",1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,";
        string menuIds = GlobalMob.User.MenuIds;
        fmenuList = fmenuList.Where<MenuModelItem>((Func<MenuModelItem, bool>) (x => menuIds.Contains("," + x.MenuId.ToString() + ","))).ToList<MenuModelItem>();
      }
      int num1 = 2;
      int num2 = fmenuList.Count<MenuModelItem>() / num1;
      Grid grid = new Grid();
      ((VisualElement) grid).BackgroundColor = Color.Black;
      ((View) grid).Margin = Thickness.op_Implicit(10.0);
      for (int index = 0; index < num1; ++index)
        ((DefinitionCollection<ColumnDefinition>) grid.ColumnDefinitions).Add(new ColumnDefinition()
        {
          Width = new GridLength(1.0, (GridUnitType) 1)
        });
      for (int index = 0; index < num2; ++index)
        ((DefinitionCollection<RowDefinition>) grid.RowDefinitions).Add(new RowDefinition()
        {
          Height = new GridLength(1.0, (GridUnitType) 1)
        });
      int num3 = 0;
      int num4 = 0;
      int num5 = 0;
      foreach (MenuModelItem fmenu in fmenuList)
      {
        ++num5;
        StackLayout stackLayout = this.AddMenuItem(fmenu.ImageName, fmenu.Title, fmenu.ColorCode, fmenu.MenuId);
        grid.Children.Add((View) stackLayout, num3, num4);
        if (num5 == fmenuList.Count<MenuModelItem>() && num3 < num1)
          Grid.SetColumnSpan((BindableObject) stackLayout, num1 - num3);
        if (num3 == num1 - 1)
        {
          ++num4;
          num3 = 0;
        }
        else
          ++num3;
      }
      this.Content = (View) grid;
      ToolbarItem toolbarItem1 = new ToolbarItem();
      ((MenuItem) toolbarItem1).Text = "Ayarlar";
      ToolbarItem toolbarItem2 = toolbarItem1;
      ((MenuItem) toolbarItem2).Clicked += new EventHandler(this.TSettings_Clicked);
      ((ICollection<ToolbarItem>) ((Page) this).ToolbarItems).Add(toolbarItem2);
      this.RefreshCounters();
      Device.StartTimer(TimeSpan.FromSeconds(15.0), (Func<bool>) (() =>
      {
        this.RefreshCounters();
        return true;
      }));
    }

    private async void TSettings_Clicked(object sender, EventArgs e) => await ((NavigableElement) this).Navigation.PushAsync((Page) new UserSettings());

    private void RefreshCounters()
    {
      try
      {
        ReturnModel returnModel = GlobalMob.PostJson(string.Format("GetPendingJobs?userID={0}", (object) GlobalMob.User.UserID), (ContentPage) null);
        if (!returnModel.Success)
          return;
        List<pIOOrderPendingJobsReturnModel> pendingJobsReturnModelList = JsonConvert.DeserializeObject<List<pIOOrderPendingJobsReturnModel>>(returnModel.Result);
        if (pendingJobsReturnModelList.Count <= 0)
          return;
        Label counterLabel1 = this.CounterLabelList[0];
        int? orderCount = pendingJobsReturnModelList[0].OrderCount;
        int num1 = 0;
        string str1 = orderCount.GetValueOrDefault() > num1 & orderCount.HasValue ? Convert.ToString((object) pendingJobsReturnModelList[0].OrderCount) : "";
        counterLabel1.Text = str1;
        Label counterLabel2 = this.CounterLabelList[1];
        int? basketCount = pendingJobsReturnModelList[0].BasketCount;
        int num2 = 0;
        string str2 = basketCount.GetValueOrDefault() > num2 & basketCount.HasValue ? Convert.ToString((object) pendingJobsReturnModelList[0].BasketCount) : "";
        counterLabel2.Text = str2;
        Label counterLabel3 = this.CounterLabelList[2];
        int? purchaseCount = pendingJobsReturnModelList[0].PurchaseCount;
        int num3 = 0;
        string str3 = purchaseCount.GetValueOrDefault() > num3 & purchaseCount.HasValue ? Convert.ToString((object) pendingJobsReturnModelList[0].PurchaseCount) : "";
        counterLabel3.Text = str3;
      }
      catch (Exception ex)
      {
      }
    }

    private StackLayout AddMenuItem(
      string image,
      string title,
      string colorCode,
      int menuId)
    {
      StackLayout stackLayout1 = new StackLayout();
      ((VisualElement) stackLayout1).BackgroundColor = Color.White;
      ((View) stackLayout1).VerticalOptions = LayoutOptions.FillAndExpand;
      StackLayout stackLayout2 = new StackLayout();
      ((View) stackLayout2).VerticalOptions = LayoutOptions.CenterAndExpand;
      ((View) stackLayout2).HorizontalOptions = LayoutOptions.CenterAndExpand;
      Grid grid = new Grid();
      ((Element) grid).ClassId = "frame" + menuId.ToString();
      ((View) grid).VerticalOptions = LayoutOptions.Center;
      ((DefinitionCollection<ColumnDefinition>) grid.ColumnDefinitions).Add(new ColumnDefinition()
      {
        Width = new GridLength(1.0, (GridUnitType) 1)
      });
      ((DefinitionCollection<RowDefinition>) grid.RowDefinitions).Add(new RowDefinition()
      {
        Height = new GridLength(1.0, (GridUnitType) 1)
      });
      Frame frame = new Frame();
      ((VisualElement) frame).BackgroundColor = Color.FromHex(colorCode);
      frame.HasShadow = false;
      frame.CornerRadius = 50f;
      ((VisualElement) frame).HeightRequest = 50.0;
      ((VisualElement) frame).WidthRequest = 50.0;
      ((View) frame).HorizontalOptions = LayoutOptions.CenterAndExpand;
      ((View) frame).VerticalOptions = LayoutOptions.Center;
      StackLayout stackLayout3 = new StackLayout();
      ((View) stackLayout3).VerticalOptions = LayoutOptions.Center;
      Image image1 = new Image();
      image1.Source = ImageSource.op_Implicit(image);
      ((View) image1).HorizontalOptions = LayoutOptions.Center;
      ((View) image1).VerticalOptions = LayoutOptions.Start;
      ((ICollection<View>) ((Layout<View>) stackLayout3).Children).Add((View) image1);
      ((ContentView) frame).Content = (View) stackLayout3;
      Label label1 = new Label();
      label1.Text = "";
      ((Element) label1).ClassId = "counter" + Convert.ToString(menuId);
      ((View) label1).Margin = new Thickness(100.0, 0.0, 0.0, 0.0);
      label1.TextColor = Color.FromHex(colorCode);
      ((View) label1).VerticalOptions = LayoutOptions.Start;
      ((View) label1).HorizontalOptions = LayoutOptions.Center;
      label1.FontAttributes = (FontAttributes) 1;
      label1.HorizontalTextAlignment = (TextAlignment) 1;
      label1.VerticalTextAlignment = (TextAlignment) 2;
      label1.FontSize = 20.0;
      if (menuId <= 3)
        this.CounterLabelList.Add(label1);
      grid.Children.Add((View) frame, 0, 0);
      grid.Children.Add((View) label1, 0, 0);
      Label label2 = new Label();
      label2.Text = title;
      ((View) label2).Margin = Thickness.op_Implicit(0.0);
      label2.TextColor = Color.Black;
      ((View) label2).VerticalOptions = LayoutOptions.Center;
      ((View) label2).HorizontalOptions = LayoutOptions.Center;
      label2.FontAttributes = (FontAttributes) 1;
      label2.HorizontalTextAlignment = (TextAlignment) 0;
      label2.VerticalTextAlignment = (TextAlignment) 2;
      ((ICollection<View>) ((Layout<View>) stackLayout2).Children).Add((View) grid);
      ((ICollection<View>) ((Layout<View>) stackLayout2).Children).Add((View) label2);
      ((ICollection<View>) ((Layout<View>) stackLayout1).Children).Add((View) stackLayout2);
      TapGestureRecognizer gestureRecognizer = new TapGestureRecognizer();
      gestureRecognizer.CommandParameter = (object) menuId;
      gestureRecognizer.Tapped += (EventHandler) ((s, e) => this.OnTapped(s, e));
      ((ICollection<IGestureRecognizer>) ((View) stackLayout1).GestureRecognizers).Add((IGestureRecognizer) gestureRecognizer);
      return stackLayout1;
    }

    protected virtual bool OnBackButtonPressed()
    {
      if (this._canClose)
        this.ShowExitDialog();
      return this._canClose;
    }

    private async void ShowExitDialog()
    {
      MainPage mainPage = this;
      if (!await ((Page) mainPage).DisplayAlert("Çıkış?", "Programdan çıkmak istiyor musunuz?", "Evet", "Hayır"))
        return;
      GlobalMob.Exit();
      mainPage._canClose = false;
      ((Page) mainPage).OnBackButtonPressed();
    }

    public async void BackButtonPressed(bool isExit)
    {
      isExit = await ((Page) this).DisplayAlert("Çıkış?", "Programdan çıkmak istiyor musunuz?", "Evet", "Hayır");
      if (!isExit)
        return;
      GlobalMob.Exit();
    }

    private async void OnTapped(object sender, EventArgs e)
    {
      MainPage page = this;
      StackLayout stck;
      if (page.isClick)
      {
        stck = (StackLayout) null;
      }
      else
      {
        page.isClick = true;
        if (!GlobalMob.PostJson("Get", (ContentPage) page).Success)
        {
          page.isClick = false;
          stck = (StackLayout) null;
        }
        else
        {
          stck = (StackLayout) sender;
          ((VisualElement) stck).Opacity = 0.9;
          string c = Convert.ToString(((TappedEventArgs) e).Parameter);
          MenuModelItem menuItem = page.menuList.Where<MenuModelItem>((Func<MenuModelItem, bool>) (x => x.MenuId == Convert.ToInt32(c))).FirstOrDefault<MenuModelItem>();
          if (menuItem != null)
          {
            List<MenuModelItem> list = page.menuList.Where<MenuModelItem>((Func<MenuModelItem, bool>) (x => x.HeaderMenuID == menuItem.MenuId)).ToList<MenuModelItem>();
            if (list.Count > 1)
            {
              MainPage mainPage = new MainPage(list);
              ((Page) mainPage).Title = menuItem.Title;
              mainPage.ButtonColor = menuItem.Color;
              await ((NavigableElement) page).Navigation.PushAsync((Page) mainPage);
              ((VisualElement) stck).Opacity = 1.0;
              page.isClick = false;
              stck = (StackLayout) null;
            }
            else
            {
              GlobalMob.MenuColor = menuItem.Color;
              GlobalMob.CurrentMenuItem = menuItem;
              object instance = Activator.CreateInstance(Type.GetType(menuItem.pageName));
              GlobalMob.currentPage = (ContentPage) instance;
              await ((NavigableElement) page).Navigation.PushAsync((Page) instance);
              ((VisualElement) stck).Opacity = 1.0;
              page.isClick = false;
              stck = (StackLayout) null;
            }
          }
          else
          {
            ((VisualElement) stck).Opacity = 1.0;
            page.isClick = false;
            stck = (StackLayout) null;
          }
        }
      }
    }

    protected virtual void OnAppearing()
    {
      ((Page) this).OnAppearing();
      ((NavigationPage) Application.Current.MainPage).BarBackgroundColor = this.ButtonColor;
    }

    [GeneratedCode("Xamarin.Forms.Build.Tasks.XamlG", "2.0.0.0")]
    private void InitializeComponent()
    {
      if (ResourceLoader.CanProvideContentFor(new ResourceLoader.ResourceLoadingQuery()
      {
        AssemblyName = typeof (MainPage).GetTypeInfo().Assembly.GetName(),
        ResourcePath = "Views/MainPage.xaml",
        Instance = (object) this
      }))
        this.__InitComponentRuntime();
      else if (XamlLoader.XamlFileProvider != null && XamlLoader.XamlFileProvider(((object) this).GetType()) != null)
      {
        this.__InitComponentRuntime();
      }
      else
      {
        RowDefinition rowDefinition1 = new RowDefinition();
        RowDefinition rowDefinition2 = new RowDefinition();
        RowDefinition rowDefinition3 = new RowDefinition();
        ColumnDefinition columnDefinition1 = new ColumnDefinition();
        ColumnDefinition columnDefinition2 = new ColumnDefinition();
        TapGestureRecognizer gestureRecognizer1 = new TapGestureRecognizer();
        BoxView boxView1 = new BoxView();
        Image image1 = new Image();
        Label label1 = new Label();
        StackLayout stackLayout1 = new StackLayout();
        TapGestureRecognizer gestureRecognizer2 = new TapGestureRecognizer();
        BoxView boxView2 = new BoxView();
        Image image2 = new Image();
        Label label2 = new Label();
        StackLayout stackLayout2 = new StackLayout();
        TapGestureRecognizer gestureRecognizer3 = new TapGestureRecognizer();
        BoxView boxView3 = new BoxView();
        Image image3 = new Image();
        Label label3 = new Label();
        StackLayout stackLayout3 = new StackLayout();
        TapGestureRecognizer gestureRecognizer4 = new TapGestureRecognizer();
        BoxView boxView4 = new BoxView();
        Image image4 = new Image();
        Label label4 = new Label();
        StackLayout stackLayout4 = new StackLayout();
        TapGestureRecognizer gestureRecognizer5 = new TapGestureRecognizer();
        BoxView boxView5 = new BoxView();
        Image image5 = new Image();
        Label label5 = new Label();
        StackLayout stackLayout5 = new StackLayout();
        TapGestureRecognizer gestureRecognizer6 = new TapGestureRecognizer();
        BoxView boxView6 = new BoxView();
        Image image6 = new Image();
        Label label6 = new Label();
        StackLayout stackLayout6 = new StackLayout();
        Grid grid = new Grid();
        MainPage mainPage;
        NameScope nameScope = (NameScope) (NameScope.GetNameScope((BindableObject) (mainPage = this)) ?? (INameScope) new NameScope());
        NameScope.SetNameScope((BindableObject) mainPage, (INameScope) nameScope);
        ((INameScope) nameScope).RegisterName("mainPage", (object) mainPage);
        if (((Element) mainPage).StyleId == null)
          ((Element) mainPage).StyleId = "mainPage";
        ((INameScope) nameScope).RegisterName("picking", (object) stackLayout1);
        if (((Element) stackLayout1).StyleId == null)
          ((Element) stackLayout1).StyleId = "picking";
        ((INameScope) nameScope).RegisterName("basket", (object) stackLayout2);
        if (((Element) stackLayout2).StyleId == null)
          ((Element) stackLayout2).StyleId = "basket";
        ((INameScope) nameScope).RegisterName("shelfentry", (object) stackLayout3);
        if (((Element) stackLayout3).StyleId == null)
          ((Element) stackLayout3).StyleId = "shelfentry";
        this.mainPage = (ContentPage) mainPage;
        this.picking = stackLayout1;
        this.basket = stackLayout2;
        this.shelfentry = stackLayout3;
        ((BindableObject) grid).SetValue(VisualElement.BackgroundColorProperty, (object) Color.Black);
        ((BindableObject) grid).SetValue(View.MarginProperty, (object) new Thickness(10.0));
        ((BindableObject) rowDefinition1).SetValue(RowDefinition.HeightProperty, new GridLengthTypeConverter().ConvertFromInvariantString("*"));
        ((DefinitionCollection<RowDefinition>) ((BindableObject) grid).GetValue(Grid.RowDefinitionsProperty)).Add(rowDefinition1);
        ((BindableObject) rowDefinition2).SetValue(RowDefinition.HeightProperty, new GridLengthTypeConverter().ConvertFromInvariantString("*"));
        ((DefinitionCollection<RowDefinition>) ((BindableObject) grid).GetValue(Grid.RowDefinitionsProperty)).Add(rowDefinition2);
        ((BindableObject) rowDefinition3).SetValue(RowDefinition.HeightProperty, new GridLengthTypeConverter().ConvertFromInvariantString("*"));
        ((DefinitionCollection<RowDefinition>) ((BindableObject) grid).GetValue(Grid.RowDefinitionsProperty)).Add(rowDefinition3);
        ((BindableObject) columnDefinition1).SetValue(ColumnDefinition.WidthProperty, new GridLengthTypeConverter().ConvertFromInvariantString("*"));
        ((DefinitionCollection<ColumnDefinition>) ((BindableObject) grid).GetValue(Grid.ColumnDefinitionsProperty)).Add(columnDefinition1);
        ((BindableObject) columnDefinition2).SetValue(ColumnDefinition.WidthProperty, new GridLengthTypeConverter().ConvertFromInvariantString("*"));
        ((DefinitionCollection<ColumnDefinition>) ((BindableObject) grid).GetValue(Grid.ColumnDefinitionsProperty)).Add(columnDefinition2);
        ((BindableObject) stackLayout1).SetValue(Grid.ColumnProperty, (object) 0);
        ((BindableObject) stackLayout1).SetValue(VisualElement.BackgroundColorProperty, (object) Color.White);
        ((BindableObject) stackLayout1).SetValue(Grid.RowProperty, (object) 0);
        ((BindableObject) stackLayout1).SetValue(View.VerticalOptionsProperty, (object) LayoutOptions.FillAndExpand);
        gestureRecognizer1.Tapped += new EventHandler(mainPage.OnTapped);
        ((BindableObject) gestureRecognizer1).SetValue(TapGestureRecognizer.CommandParameterProperty, (object) "1");
        ((ICollection<IGestureRecognizer>) ((View) stackLayout1).GestureRecognizers).Add((IGestureRecognizer) gestureRecognizer1);
        VisualDiagnostics.RegisterSourceInfo((object) gestureRecognizer1, new Uri("Views\\MainPage.xaml" + ";assembly=" + "Shelf", UriKind.RelativeOrAbsolute), 25, 18);
        ((BindableObject) boxView1).SetValue(Grid.RowProperty, (object) 0);
        ((BindableObject) boxView1).SetValue(Grid.ColumnProperty, (object) 0);
        ((BindableObject) boxView1).SetValue(View.MarginProperty, (object) new Thickness(0.0));
        ((BindableObject) boxView1).SetValue(VisualElement.BackgroundColorProperty, (object) Color.White);
        ((ICollection<View>) ((Layout<View>) stackLayout1).Children).Add((View) boxView1);
        VisualDiagnostics.RegisterSourceInfo((object) boxView1, new Uri("Views\\MainPage.xaml" + ";assembly=" + "Shelf", UriKind.RelativeOrAbsolute), 20, 14);
        ((BindableObject) image1).SetValue(Image.SourceProperty, new ImageSourceConverter().ConvertFromInvariantString("product.png"));
        ((BindableObject) image1).SetValue(Grid.ColumnProperty, (object) 0);
        ((BindableObject) image1).SetValue(View.MarginProperty, (object) new Thickness(0.0));
        ((BindableObject) image1).SetValue(View.VerticalOptionsProperty, (object) LayoutOptions.Center);
        ((BindableObject) image1).SetValue(View.HorizontalOptionsProperty, (object) LayoutOptions.Center);
        ((ICollection<View>) ((Layout<View>) stackLayout1).Children).Add((View) image1);
        VisualDiagnostics.RegisterSourceInfo((object) image1, new Uri("Views\\MainPage.xaml" + ";assembly=" + "Shelf", UriKind.RelativeOrAbsolute), 21, 14);
        ((BindableObject) label1).SetValue(Label.TextProperty, (object) "ÜRÜN TOPLA");
        ((BindableObject) label1).SetValue(Grid.RowProperty, (object) 0);
        ((BindableObject) label1).SetValue(Grid.ColumnProperty, (object) 0);
        ((BindableObject) label1).SetValue(View.MarginProperty, (object) new Thickness(0.0));
        ((BindableObject) label1).SetValue(Label.TextColorProperty, (object) Color.Black);
        ((BindableObject) label1).SetValue(View.VerticalOptionsProperty, (object) LayoutOptions.Center);
        ((BindableObject) label1).SetValue(View.HorizontalOptionsProperty, (object) LayoutOptions.Center);
        ((BindableObject) label1).SetValue(Label.FontAttributesProperty, new FontAttributesConverter().ConvertFromInvariantString("Bold"));
        ((BindableObject) label1).SetValue(Label.HorizontalTextAlignmentProperty, new TextAlignmentConverter().ConvertFromInvariantString("Center"));
        ((BindableObject) label1).SetValue(Label.VerticalTextAlignmentProperty, new TextAlignmentConverter().ConvertFromInvariantString("Center"));
        ((ICollection<View>) ((Layout<View>) stackLayout1).Children).Add((View) label1);
        VisualDiagnostics.RegisterSourceInfo((object) label1, new Uri("Views\\MainPage.xaml" + ";assembly=" + "Shelf", UriKind.RelativeOrAbsolute), 22, 14);
        ((ICollection<View>) grid.Children).Add((View) stackLayout1);
        VisualDiagnostics.RegisterSourceInfo((object) stackLayout1, new Uri("Views\\MainPage.xaml" + ";assembly=" + "Shelf", UriKind.RelativeOrAbsolute), 19, 10);
        ((BindableObject) stackLayout2).SetValue(Grid.RowProperty, (object) 0);
        ((BindableObject) stackLayout2).SetValue(Grid.ColumnProperty, (object) 1);
        ((BindableObject) stackLayout2).SetValue(VisualElement.BackgroundColorProperty, (object) Color.White);
        ((BindableObject) stackLayout2).SetValue(View.VerticalOptionsProperty, (object) LayoutOptions.FillAndExpand);
        gestureRecognizer2.Tapped += new EventHandler(mainPage.OnTapped);
        ((BindableObject) gestureRecognizer2).SetValue(TapGestureRecognizer.CommandParameterProperty, (object) "2");
        ((ICollection<IGestureRecognizer>) ((View) stackLayout2).GestureRecognizers).Add((IGestureRecognizer) gestureRecognizer2);
        VisualDiagnostics.RegisterSourceInfo((object) gestureRecognizer2, new Uri("Views\\MainPage.xaml" + ";assembly=" + "Shelf", UriKind.RelativeOrAbsolute), 35, 18);
        ((BindableObject) boxView2).SetValue(Grid.RowProperty, (object) 0);
        ((BindableObject) boxView2).SetValue(Grid.ColumnProperty, (object) 1);
        ((BindableObject) boxView2).SetValue(View.MarginProperty, (object) new Thickness(0.0));
        ((BindableObject) boxView2).SetValue(VisualElement.BackgroundColorProperty, (object) Color.White);
        ((ICollection<View>) ((Layout<View>) stackLayout2).Children).Add((View) boxView2);
        VisualDiagnostics.RegisterSourceInfo((object) boxView2, new Uri("Views\\MainPage.xaml" + ";assembly=" + "Shelf", UriKind.RelativeOrAbsolute), 30, 14);
        ((BindableObject) image2).SetValue(Image.SourceProperty, new ImageSourceConverter().ConvertFromInvariantString("basket.png"));
        ((BindableObject) image2).SetValue(Grid.RowProperty, (object) 0);
        ((BindableObject) image2).SetValue(Grid.ColumnProperty, (object) 1);
        ((BindableObject) image2).SetValue(View.MarginProperty, (object) new Thickness(0.0));
        ((BindableObject) image2).SetValue(View.VerticalOptionsProperty, (object) LayoutOptions.Center);
        ((BindableObject) image2).SetValue(View.HorizontalOptionsProperty, (object) LayoutOptions.Center);
        ((ICollection<View>) ((Layout<View>) stackLayout2).Children).Add((View) image2);
        VisualDiagnostics.RegisterSourceInfo((object) image2, new Uri("Views\\MainPage.xaml" + ";assembly=" + "Shelf", UriKind.RelativeOrAbsolute), 31, 14);
        ((BindableObject) label2).SetValue(Label.TextProperty, (object) "SEPET OKUT");
        ((BindableObject) label2).SetValue(Grid.RowProperty, (object) 0);
        ((BindableObject) label2).SetValue(Grid.ColumnProperty, (object) 1);
        ((BindableObject) label2).SetValue(View.MarginProperty, (object) new Thickness(0.0));
        ((BindableObject) label2).SetValue(Label.TextColorProperty, (object) Color.Black);
        ((BindableObject) label2).SetValue(View.VerticalOptionsProperty, (object) LayoutOptions.Center);
        ((BindableObject) label2).SetValue(View.HorizontalOptionsProperty, (object) LayoutOptions.Center);
        ((BindableObject) label2).SetValue(Label.FontAttributesProperty, new FontAttributesConverter().ConvertFromInvariantString("Bold"));
        ((BindableObject) label2).SetValue(Label.HorizontalTextAlignmentProperty, new TextAlignmentConverter().ConvertFromInvariantString("Center"));
        ((BindableObject) label2).SetValue(Label.VerticalTextAlignmentProperty, new TextAlignmentConverter().ConvertFromInvariantString("Center"));
        ((ICollection<View>) ((Layout<View>) stackLayout2).Children).Add((View) label2);
        VisualDiagnostics.RegisterSourceInfo((object) label2, new Uri("Views\\MainPage.xaml" + ";assembly=" + "Shelf", UriKind.RelativeOrAbsolute), 32, 14);
        ((ICollection<View>) grid.Children).Add((View) stackLayout2);
        VisualDiagnostics.RegisterSourceInfo((object) stackLayout2, new Uri("Views\\MainPage.xaml" + ";assembly=" + "Shelf", UriKind.RelativeOrAbsolute), 29, 10);
        ((BindableObject) stackLayout3).SetValue(Grid.RowProperty, (object) 1);
        ((BindableObject) stackLayout3).SetValue(Grid.ColumnProperty, (object) 0);
        ((BindableObject) stackLayout3).SetValue(VisualElement.BackgroundColorProperty, (object) Color.White);
        ((BindableObject) stackLayout3).SetValue(View.VerticalOptionsProperty, (object) LayoutOptions.FillAndExpand);
        gestureRecognizer3.Tapped += new EventHandler(mainPage.OnTapped);
        ((BindableObject) gestureRecognizer3).SetValue(TapGestureRecognizer.CommandParameterProperty, (object) "3");
        ((ICollection<IGestureRecognizer>) ((View) stackLayout3).GestureRecognizers).Add((IGestureRecognizer) gestureRecognizer3);
        VisualDiagnostics.RegisterSourceInfo((object) gestureRecognizer3, new Uri("Views\\MainPage.xaml" + ";assembly=" + "Shelf", UriKind.RelativeOrAbsolute), 46, 18);
        ((BindableObject) boxView3).SetValue(Grid.RowProperty, (object) 1);
        ((BindableObject) boxView3).SetValue(Grid.ColumnProperty, (object) 0);
        ((BindableObject) boxView3).SetValue(View.MarginProperty, (object) new Thickness(0.0));
        ((BindableObject) boxView3).SetValue(VisualElement.BackgroundColorProperty, (object) Color.White);
        ((ICollection<View>) ((Layout<View>) stackLayout3).Children).Add((View) boxView3);
        VisualDiagnostics.RegisterSourceInfo((object) boxView3, new Uri("Views\\MainPage.xaml" + ";assembly=" + "Shelf", UriKind.RelativeOrAbsolute), 41, 14);
        ((BindableObject) image3).SetValue(Image.SourceProperty, new ImageSourceConverter().ConvertFromInvariantString("shelf.png"));
        ((BindableObject) image3).SetValue(Grid.RowProperty, (object) 1);
        ((BindableObject) image3).SetValue(Grid.ColumnProperty, (object) 0);
        ((BindableObject) image3).SetValue(View.MarginProperty, (object) new Thickness(0.0));
        ((BindableObject) image3).SetValue(View.VerticalOptionsProperty, (object) LayoutOptions.Center);
        ((BindableObject) image3).SetValue(View.HorizontalOptionsProperty, (object) LayoutOptions.Center);
        ((ICollection<View>) ((Layout<View>) stackLayout3).Children).Add((View) image3);
        VisualDiagnostics.RegisterSourceInfo((object) image3, new Uri("Views\\MainPage.xaml" + ";assembly=" + "Shelf", UriKind.RelativeOrAbsolute), 42, 14);
        ((BindableObject) label3).SetValue(Label.TextProperty, (object) "RAF GİRİŞİ (İRSALİYELİ)");
        ((BindableObject) label3).SetValue(Grid.RowProperty, (object) 1);
        ((BindableObject) label3).SetValue(Grid.ColumnProperty, (object) 0);
        ((BindableObject) label3).SetValue(View.MarginProperty, (object) new Thickness(0.0));
        ((BindableObject) label3).SetValue(Label.TextColorProperty, (object) Color.Black);
        ((BindableObject) label3).SetValue(View.VerticalOptionsProperty, (object) LayoutOptions.Center);
        ((BindableObject) label3).SetValue(View.HorizontalOptionsProperty, (object) LayoutOptions.Center);
        ((BindableObject) label3).SetValue(Label.FontAttributesProperty, new FontAttributesConverter().ConvertFromInvariantString("Bold"));
        ((BindableObject) label3).SetValue(Label.HorizontalTextAlignmentProperty, new TextAlignmentConverter().ConvertFromInvariantString("Center"));
        ((BindableObject) label3).SetValue(Label.VerticalTextAlignmentProperty, new TextAlignmentConverter().ConvertFromInvariantString("Center"));
        ((ICollection<View>) ((Layout<View>) stackLayout3).Children).Add((View) label3);
        VisualDiagnostics.RegisterSourceInfo((object) label3, new Uri("Views\\MainPage.xaml" + ";assembly=" + "Shelf", UriKind.RelativeOrAbsolute), 43, 14);
        ((ICollection<View>) grid.Children).Add((View) stackLayout3);
        VisualDiagnostics.RegisterSourceInfo((object) stackLayout3, new Uri("Views\\MainPage.xaml" + ";assembly=" + "Shelf", UriKind.RelativeOrAbsolute), 40, 10);
        ((BindableObject) stackLayout4).SetValue(Grid.RowProperty, (object) 1);
        ((BindableObject) stackLayout4).SetValue(Grid.ColumnProperty, (object) 1);
        ((BindableObject) stackLayout4).SetValue(VisualElement.BackgroundColorProperty, (object) Color.White);
        ((BindableObject) stackLayout4).SetValue(View.VerticalOptionsProperty, (object) LayoutOptions.FillAndExpand);
        gestureRecognizer4.Tapped += new EventHandler(mainPage.OnTapped);
        ((BindableObject) gestureRecognizer4).SetValue(TapGestureRecognizer.CommandParameterProperty, (object) "4");
        ((ICollection<IGestureRecognizer>) ((View) stackLayout4).GestureRecognizers).Add((IGestureRecognizer) gestureRecognizer4);
        VisualDiagnostics.RegisterSourceInfo((object) gestureRecognizer4, new Uri("Views\\MainPage.xaml" + ";assembly=" + "Shelf", UriKind.RelativeOrAbsolute), 56, 18);
        ((BindableObject) boxView4).SetValue(Grid.RowProperty, (object) 1);
        ((BindableObject) boxView4).SetValue(Grid.ColumnProperty, (object) 1);
        ((BindableObject) boxView4).SetValue(View.MarginProperty, (object) new Thickness(0.0));
        ((BindableObject) boxView4).SetValue(VisualElement.BackgroundColorProperty, (object) Color.White);
        ((ICollection<View>) ((Layout<View>) stackLayout4).Children).Add((View) boxView4);
        VisualDiagnostics.RegisterSourceInfo((object) boxView4, new Uri("Views\\MainPage.xaml" + ";assembly=" + "Shelf", UriKind.RelativeOrAbsolute), 51, 14);
        ((BindableObject) image4).SetValue(Image.SourceProperty, new ImageSourceConverter().ConvertFromInvariantString("shelf.png"));
        ((BindableObject) image4).SetValue(Grid.RowProperty, (object) 1);
        ((BindableObject) image4).SetValue(Grid.ColumnProperty, (object) 1);
        ((BindableObject) image4).SetValue(View.MarginProperty, (object) new Thickness(0.0));
        ((BindableObject) image4).SetValue(View.VerticalOptionsProperty, (object) LayoutOptions.Center);
        ((BindableObject) image4).SetValue(View.HorizontalOptionsProperty, (object) LayoutOptions.Center);
        ((ICollection<View>) ((Layout<View>) stackLayout4).Children).Add((View) image4);
        VisualDiagnostics.RegisterSourceInfo((object) image4, new Uri("Views\\MainPage.xaml" + ";assembly=" + "Shelf", UriKind.RelativeOrAbsolute), 52, 14);
        ((BindableObject) label4).SetValue(Label.TextProperty, (object) "RAF GİRİŞİ (SERBEST)");
        ((BindableObject) label4).SetValue(Grid.RowProperty, (object) 1);
        ((BindableObject) label4).SetValue(Grid.ColumnProperty, (object) 1);
        ((BindableObject) label4).SetValue(View.MarginProperty, (object) new Thickness(0.0));
        ((BindableObject) label4).SetValue(Label.TextColorProperty, (object) Color.Black);
        ((BindableObject) label4).SetValue(View.VerticalOptionsProperty, (object) LayoutOptions.Center);
        ((BindableObject) label4).SetValue(View.HorizontalOptionsProperty, (object) LayoutOptions.Center);
        ((BindableObject) label4).SetValue(Label.FontAttributesProperty, new FontAttributesConverter().ConvertFromInvariantString("Bold"));
        ((BindableObject) label4).SetValue(Label.HorizontalTextAlignmentProperty, new TextAlignmentConverter().ConvertFromInvariantString("Center"));
        ((BindableObject) label4).SetValue(Label.VerticalTextAlignmentProperty, new TextAlignmentConverter().ConvertFromInvariantString("Center"));
        ((ICollection<View>) ((Layout<View>) stackLayout4).Children).Add((View) label4);
        VisualDiagnostics.RegisterSourceInfo((object) label4, new Uri("Views\\MainPage.xaml" + ";assembly=" + "Shelf", UriKind.RelativeOrAbsolute), 53, 14);
        ((ICollection<View>) grid.Children).Add((View) stackLayout4);
        VisualDiagnostics.RegisterSourceInfo((object) stackLayout4, new Uri("Views\\MainPage.xaml" + ";assembly=" + "Shelf", UriKind.RelativeOrAbsolute), 50, 10);
        ((BindableObject) stackLayout5).SetValue(Grid.RowProperty, (object) 2);
        ((BindableObject) stackLayout5).SetValue(Grid.ColumnProperty, (object) 0);
        ((BindableObject) stackLayout5).SetValue(VisualElement.BackgroundColorProperty, (object) Color.White);
        ((BindableObject) stackLayout5).SetValue(View.VerticalOptionsProperty, (object) LayoutOptions.FillAndExpand);
        gestureRecognizer5.Tapped += new EventHandler(mainPage.OnTapped);
        ((BindableObject) gestureRecognizer5).SetValue(TapGestureRecognizer.CommandParameterProperty, (object) "5");
        ((ICollection<IGestureRecognizer>) ((View) stackLayout5).GestureRecognizers).Add((IGestureRecognizer) gestureRecognizer5);
        VisualDiagnostics.RegisterSourceInfo((object) gestureRecognizer5, new Uri("Views\\MainPage.xaml" + ";assembly=" + "Shelf", UriKind.RelativeOrAbsolute), 67, 18);
        ((BindableObject) boxView5).SetValue(Grid.RowProperty, (object) 2);
        ((BindableObject) boxView5).SetValue(Grid.ColumnProperty, (object) 0);
        ((BindableObject) boxView5).SetValue(View.MarginProperty, (object) new Thickness(0.0));
        ((BindableObject) boxView5).SetValue(VisualElement.BackgroundColorProperty, (object) Color.White);
        ((ICollection<View>) ((Layout<View>) stackLayout5).Children).Add((View) boxView5);
        VisualDiagnostics.RegisterSourceInfo((object) boxView5, new Uri("Views\\MainPage.xaml" + ";assembly=" + "Shelf", UriKind.RelativeOrAbsolute), 62, 14);
        ((BindableObject) image5).SetValue(Image.SourceProperty, new ImageSourceConverter().ConvertFromInvariantString("shelfcounting.png"));
        ((BindableObject) image5).SetValue(Grid.RowProperty, (object) 2);
        ((BindableObject) image5).SetValue(Grid.ColumnProperty, (object) 0);
        ((BindableObject) image5).SetValue(View.MarginProperty, (object) new Thickness(0.0));
        ((BindableObject) image5).SetValue(View.VerticalOptionsProperty, (object) LayoutOptions.Center);
        ((BindableObject) image5).SetValue(View.HorizontalOptionsProperty, (object) LayoutOptions.Center);
        ((ICollection<View>) ((Layout<View>) stackLayout5).Children).Add((View) image5);
        VisualDiagnostics.RegisterSourceInfo((object) image5, new Uri("Views\\MainPage.xaml" + ";assembly=" + "Shelf", UriKind.RelativeOrAbsolute), 63, 14);
        ((BindableObject) label5).SetValue(Label.TextProperty, (object) "RAF SAYIM");
        ((BindableObject) label5).SetValue(Grid.RowProperty, (object) 2);
        ((BindableObject) label5).SetValue(Grid.ColumnProperty, (object) 0);
        ((BindableObject) label5).SetValue(View.MarginProperty, (object) new Thickness(0.0));
        ((BindableObject) label5).SetValue(Label.TextColorProperty, (object) Color.Black);
        ((BindableObject) label5).SetValue(View.VerticalOptionsProperty, (object) LayoutOptions.Center);
        ((BindableObject) label5).SetValue(View.HorizontalOptionsProperty, (object) LayoutOptions.Center);
        ((BindableObject) label5).SetValue(Label.FontAttributesProperty, new FontAttributesConverter().ConvertFromInvariantString("Bold"));
        ((BindableObject) label5).SetValue(Label.HorizontalTextAlignmentProperty, new TextAlignmentConverter().ConvertFromInvariantString("Center"));
        ((BindableObject) label5).SetValue(Label.VerticalTextAlignmentProperty, new TextAlignmentConverter().ConvertFromInvariantString("Center"));
        ((ICollection<View>) ((Layout<View>) stackLayout5).Children).Add((View) label5);
        VisualDiagnostics.RegisterSourceInfo((object) label5, new Uri("Views\\MainPage.xaml" + ";assembly=" + "Shelf", UriKind.RelativeOrAbsolute), 64, 14);
        ((ICollection<View>) grid.Children).Add((View) stackLayout5);
        VisualDiagnostics.RegisterSourceInfo((object) stackLayout5, new Uri("Views\\MainPage.xaml" + ";assembly=" + "Shelf", UriKind.RelativeOrAbsolute), 61, 10);
        ((BindableObject) stackLayout6).SetValue(Grid.RowProperty, (object) 2);
        ((BindableObject) stackLayout6).SetValue(Grid.ColumnProperty, (object) 1);
        ((BindableObject) stackLayout6).SetValue(VisualElement.BackgroundColorProperty, (object) Color.White);
        ((BindableObject) stackLayout6).SetValue(View.VerticalOptionsProperty, (object) LayoutOptions.FillAndExpand);
        gestureRecognizer6.Tapped += new EventHandler(mainPage.OnTapped);
        ((BindableObject) gestureRecognizer6).SetValue(TapGestureRecognizer.CommandParameterProperty, (object) "6");
        ((ICollection<IGestureRecognizer>) ((View) stackLayout6).GestureRecognizers).Add((IGestureRecognizer) gestureRecognizer6);
        VisualDiagnostics.RegisterSourceInfo((object) gestureRecognizer6, new Uri("Views\\MainPage.xaml" + ";assembly=" + "Shelf", UriKind.RelativeOrAbsolute), 77, 18);
        ((BindableObject) boxView6).SetValue(Grid.RowProperty, (object) 2);
        ((BindableObject) boxView6).SetValue(Grid.ColumnProperty, (object) 1);
        ((BindableObject) boxView6).SetValue(View.MarginProperty, (object) new Thickness(0.0));
        ((BindableObject) boxView6).SetValue(VisualElement.BackgroundColorProperty, (object) Color.White);
        ((ICollection<View>) ((Layout<View>) stackLayout6).Children).Add((View) boxView6);
        VisualDiagnostics.RegisterSourceInfo((object) boxView6, new Uri("Views\\MainPage.xaml" + ";assembly=" + "Shelf", UriKind.RelativeOrAbsolute), 72, 14);
        ((BindableObject) image6).SetValue(Image.SourceProperty, new ImageSourceConverter().ConvertFromInvariantString("shelfoutput.png"));
        ((BindableObject) image6).SetValue(Grid.RowProperty, (object) 2);
        ((BindableObject) image6).SetValue(Grid.ColumnProperty, (object) 1);
        ((BindableObject) image6).SetValue(View.MarginProperty, (object) new Thickness(0.0));
        ((BindableObject) image6).SetValue(View.VerticalOptionsProperty, (object) LayoutOptions.Center);
        ((BindableObject) image6).SetValue(View.HorizontalOptionsProperty, (object) LayoutOptions.Center);
        ((ICollection<View>) ((Layout<View>) stackLayout6).Children).Add((View) image6);
        VisualDiagnostics.RegisterSourceInfo((object) image6, new Uri("Views\\MainPage.xaml" + ";assembly=" + "Shelf", UriKind.RelativeOrAbsolute), 73, 14);
        ((BindableObject) label6).SetValue(Label.TextProperty, (object) "RAF ÇIKIŞ");
        ((BindableObject) label6).SetValue(Grid.RowProperty, (object) 2);
        ((BindableObject) label6).SetValue(Grid.ColumnProperty, (object) 1);
        ((BindableObject) label6).SetValue(View.MarginProperty, (object) new Thickness(0.0));
        ((BindableObject) label6).SetValue(Label.TextColorProperty, (object) Color.Black);
        ((BindableObject) label6).SetValue(View.VerticalOptionsProperty, (object) LayoutOptions.Center);
        ((BindableObject) label6).SetValue(View.HorizontalOptionsProperty, (object) LayoutOptions.Center);
        ((BindableObject) label6).SetValue(Label.FontAttributesProperty, new FontAttributesConverter().ConvertFromInvariantString("Bold"));
        ((BindableObject) label6).SetValue(Label.HorizontalTextAlignmentProperty, new TextAlignmentConverter().ConvertFromInvariantString("Center"));
        ((BindableObject) label6).SetValue(Label.VerticalTextAlignmentProperty, new TextAlignmentConverter().ConvertFromInvariantString("Center"));
        ((ICollection<View>) ((Layout<View>) stackLayout6).Children).Add((View) label6);
        VisualDiagnostics.RegisterSourceInfo((object) label6, new Uri("Views\\MainPage.xaml" + ";assembly=" + "Shelf", UriKind.RelativeOrAbsolute), 74, 14);
        ((ICollection<View>) grid.Children).Add((View) stackLayout6);
        VisualDiagnostics.RegisterSourceInfo((object) stackLayout6, new Uri("Views\\MainPage.xaml" + ";assembly=" + "Shelf", UriKind.RelativeOrAbsolute), 71, 10);
        ((BindableObject) mainPage).SetValue(ContentPage.ContentProperty, (object) grid);
        VisualDiagnostics.RegisterSourceInfo((object) grid, new Uri("Views\\MainPage.xaml" + ";assembly=" + "Shelf", UriKind.RelativeOrAbsolute), 7, 6);
        VisualDiagnostics.RegisterSourceInfo((object) mainPage, new Uri("Views\\MainPage.xaml" + ";assembly=" + "Shelf", UriKind.RelativeOrAbsolute), 2, 2);
      }
    }

    private void __InitComponentRuntime()
    {
      Extensions.LoadFromXaml<MainPage>(this, typeof (MainPage));
      this.mainPage = NameScopeExtensions.FindByName<ContentPage>((Element) this, "mainPage");
      this.picking = NameScopeExtensions.FindByName<StackLayout>((Element) this, "picking");
      this.basket = NameScopeExtensions.FindByName<StackLayout>((Element) this, "basket");
      this.shelfentry = NameScopeExtensions.FindByName<StackLayout>((Element) this, "shelfentry");
    }
  }
}
