﻿// Decompiled with JetBrains decompiler
// Type: Shelf.Models.AlcPackage
// Assembly: Shelf, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 34392FE8-51B4-4368-914A-8B6FB98A7971
// Assembly location: C:\Users\pc\reverse_engineering\com.companyname.Shelf\assemblies\Shelf.dll

namespace Shelf.Models
{
  public class AlcPackage
  {
    public string UserName { get; set; }

    public string Barcode { get; set; }

    public string OrderLineID { get; set; }

    public string OrderHeaderID { get; set; }

    public int OrderLineSumID { get; set; }

    public string LotBarcode { get; set; }

    public string LotCode { get; set; }

    public int VendorCurrAccTypeCode { get; set; }

    public string VendorCurrAccCode { get; set; }

    public string VendorSubCurrAccID { get; set; }

    public int OrderQty { get; set; }
  }
}
