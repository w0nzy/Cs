﻿// Decompiled with JetBrains decompiler
// Type: Shelf.Models.BLReport
// Assembly: Shelf, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 34392FE8-51B4-4368-914A-8B6FB98A7971
// Assembly location: C:\Users\pc\reverse_engineering\com.companyname.Shelf\assemblies\Shelf.dll

using System.Collections.Generic;

namespace Shelf.Models
{
  public class BLReport
  {
    public int ReportID { get; set; }

    public int PrinterBrandID { get; set; }

    public int FileType { get; set; }

    public int ReportTypeID { get; set; }

    public int UserID { get; set; }

    public string PrinterName { get; set; }

    public bool NetworkPrinter { get; set; }

    public int AndroidPrintType { get; set; }

    public List<BLReportParam> ParamList { get; set; }
  }
}
