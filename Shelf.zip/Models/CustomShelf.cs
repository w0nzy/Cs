﻿// Decompiled with JetBrains decompiler
// Type: Shelf.Models.CustomShelf
// Assembly: Shelf, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 34392FE8-51B4-4368-914A-8B6FB98A7971
// Assembly location: C:\Users\pc\reverse_engineering\com.companyname.Shelf\assemblies\Shelf.dll

using System;

namespace Shelf.Models
{
  public class CustomShelf
  {
    public int ShelfID { get; set; }

    public int? MainShelfID { get; set; }

    public int? HallID { get; set; }

    public string Code { get; set; }

    public string WarehouseCode { get; set; }

    public string Description { get; set; }

    public int? SortOrder { get; set; }

    public bool? IsBlocked { get; set; }

    public DateTime? CreatedDate { get; set; }

    public string CreatedUserName { get; set; }

    public DateTime? UpdatedDate { get; set; }

    public string UpdatedUserName { get; set; }

    public byte ShelfType { get; set; }

    public int? ZoneID { get; set; }

    public string DisplayDescription { get; set; }

    public bool LastReadBarcode { get; set; }
  }
}
