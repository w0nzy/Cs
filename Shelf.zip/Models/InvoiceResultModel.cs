﻿// Decompiled with JetBrains decompiler
// Type: Shelf.Models.InvoiceResultModel
// Assembly: Shelf, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 34392FE8-51B4-4368-914A-8B6FB98A7971
// Assembly location: C:\Users\pc\reverse_engineering\com.companyname.Shelf\assemblies\Shelf.dll

using System.Collections.Generic;

namespace Shelf.Models
{
  public class InvoiceResultModel
  {
    public List<InvoiceResultLine> Lines = new List<InvoiceResultLine>();

    public string UnofficialInvoiceString { get; set; }

    public string InvoiceNumber { get; set; }

    public string EInvoiceNumber { get; set; }

    public string ExceptionString { get; set; }

    public bool Success { get; set; }
  }
}
