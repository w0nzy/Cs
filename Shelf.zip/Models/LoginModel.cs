﻿// Decompiled with JetBrains decompiler
// Type: Shelf.Models.LoginModel
// Assembly: Shelf, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 34392FE8-51B4-4368-914A-8B6FB98A7971
// Assembly location: C:\Users\pc\reverse_engineering\com.companyname.Shelf\assemblies\Shelf.dll

namespace Shelf.Models
{
  public class LoginModel
  {
    public bool IsBluetoothPrinter { get; set; }

    public int MKShelfID { get; set; }

    public bool IsCreatePackageOnShelfOrderPlan { get; set; }

    public bool IsLicense { get; set; }

    public int OrderManagementUserID { get; set; }

    public int UserID { get; set; }

    public string UserName { get; set; }

    public string FirstLastName { get; set; }

    public string Password { get; set; }

    public bool IsBlocked { get; set; }

    public string ErpSalesPersonCode { get; set; }

    public string MenuIds { get; set; }

    public int PrintType { get; set; }

    public bool ManuFacturingSurvey { get; set; }

    public bool ShippingSurvey { get; set; }

    public string AccountCode { get; set; }

    public string ParasalIslemTipi { get; set; }

    public string VergiTipi { get; set; }

    public string ParaBirimi { get; set; }

    public string VadeliPesin { get; set; }

    public bool OtherCurrencyVisible { get; set; }

    public bool VatVisible { get; set; }

    public bool ApplyCampaign { get; set; }

    public bool PriceDiscount { get; set; }

    public bool IsPickingUser { get; set; }

    public bool IsReceivingUser { get; set; }

    public bool IsRulot { get; set; }

    public bool PickAndSort { get; set; }

    public bool BarcodeSearchEqual { get; set; }

    public int RequestTimeout { get; set; }

    public bool HideQty { get; set; }

    public bool IsBarcodeType { get; set; }

    public string OperationPermitPassword { get; set; }

    public bool ShelfChangeBlock { get; set; }

    public bool ShelfSyncVisible { get; set; }

    public bool ShelfCountClearVisible { get; set; }

    public bool MissingCompleted { get; set; }

    public bool PickPackageApprove { get; set; }

    public bool PieceTransfer { get; set; }

    public bool IsVersionControl { get; set; }

    public string NextVersion { get; set; }

    public bool IsPackage { get; set; }

    public bool ShowLoading { get; set; }

    public int MinimumBarcodeLength { get; set; }

    public bool IsMainShelf { get; set; }

    public string ShelfPrefix { get; set; }

    public bool IsUniqueBarcode { get; set; }

    public bool IsAskPackageCode { get; set; }

    public bool IsAskShelfCode { get; set; }

    public bool IsAskPackageType { get; set; }

    public string WarehouseCode { get; set; }
  }
}
