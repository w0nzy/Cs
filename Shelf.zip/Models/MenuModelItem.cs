﻿// Decompiled with JetBrains decompiler
// Type: Shelf.Models.MenuModelItem
// Assembly: Shelf, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 34392FE8-51B4-4368-914A-8B6FB98A7971
// Assembly location: C:\Users\pc\reverse_engineering\com.companyname.Shelf\assemblies\Shelf.dll

using Xamarin.Forms;

namespace Shelf.Models
{
  public class MenuModelItem
  {
    public string ImageName { get; set; }

    public string Title { get; set; }

    public string ColorCode { get; set; }

    public int MenuId { get; set; }

    public int HeaderMenuID { get; set; }

    public Color Color => Color.FromHex(this.ColorCode);

    public string pageName { get; set; }
  }
}
