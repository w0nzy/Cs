﻿// Decompiled with JetBrains decompiler
// Type: Shelf.Models.PackageHeader
// Assembly: Shelf, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 34392FE8-51B4-4368-914A-8B6FB98A7971
// Assembly location: C:\Users\pc\reverse_engineering\com.companyname.Shelf\assemblies\Shelf.dll

namespace Shelf.Models
{
  public class PackageHeader
  {
    public int PackageHeaderID { get; set; }

    public string PackageCode => "P" + (this.PackageHeaderID + 10000).ToString();

    public string PackageDescription { get; set; }

    public int PackageTypeID { get; set; }

    public int Qty { get; set; }
  }
}
