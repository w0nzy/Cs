﻿// Decompiled with JetBrains decompiler
// Type: Shelf.Models.PickAndSort
// Assembly: Shelf, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 34392FE8-51B4-4368-914A-8B6FB98A7971
// Assembly location: C:\Users\pc\reverse_engineering\com.companyname.Shelf\assemblies\Shelf.dll

using System;
using System.Collections.Generic;

namespace Shelf.Models
{
  public class PickAndSort
  {
    public bool ReadPackageCode { get; set; }

    public bool IsPlusOrderQty { get; set; }

    public int ShelfOrderDetailID { get; set; }

    public int PickQty { get; set; }

    public int ApproveQty { get; set; }

    public string barcode { get; set; }

    public string readbarcode { get; set; }

    public string userName { get; set; }

    public string PivotShelfCode { get; set; }

    public int ResultQty { get; set; }

    public int ShelfOrderType { get; set; }

    public int ShelfOrderID { get; set; }

    public int PackageHeaderID { get; set; }

    public int PackageDetailID { get; set; }

    public string DispOrderNumber { get; set; }

    public int ShelfType { get; set; }

    public bool isPickAndSort { get; set; }

    public Guid DispOrderLineID { get; set; }

    public bool? AutoApproveQty { get; set; }

    public bool? AutoPackedQty { get; set; }

    public int ShelfCurrAccTypeCode { get; set; }

    public bool PickPackageApprove { get; set; }

    public int ShelfID { get; set; }

    public int MKShelfID { get; set; }

    public int ZoneID { get; set; }

    public bool IsAskPackageCode { get; set; }

    public string ErrorMessage { get; set; }

    public int UserID { get; set; }

    public List<PickAndSortDetail> Detail { get; set; }
  }
}
