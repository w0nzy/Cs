﻿// Decompiled with JetBrains decompiler
// Type: Shelf.Models.PickAndSortDetail
// Assembly: Shelf, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 34392FE8-51B4-4368-914A-8B6FB98A7971
// Assembly location: C:\Users\pc\reverse_engineering\com.companyname.Shelf\assemblies\Shelf.dll

namespace Shelf.Models
{
  public class PickAndSortDetail
  {
    public string Barcode { get; set; }

    public string ItemCode { get; set; }

    public string ColorCode { get; set; }

    public string ItemDim1Code { get; set; }

    public string ItemDim2Code { get; set; }

    public int ShelfOrderDetailID { get; set; }

    public int ShelfOrderID { get; set; }

    public string DispOrderNumber { get; set; }

    public double PickingQty { get; set; }

    public double OrderQty { get; set; }

    public double ApproveQty { get; set; }

    public int PackageHeaderID { get; set; }
  }
}
