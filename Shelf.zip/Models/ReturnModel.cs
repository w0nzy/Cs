﻿// Decompiled with JetBrains decompiler
// Type: Shelf.Models.ReturnModel
// Assembly: Shelf, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 34392FE8-51B4-4368-914A-8B6FB98A7971
// Assembly location: C:\Users\pc\reverse_engineering\com.companyname.Shelf\assemblies\Shelf.dll

namespace Shelf.Models
{
  public class ReturnModel
  {
    public bool Success { get; set; }

    public string ErrorMessage { get; set; }

    public string Result { get; set; }
  }
}
