﻿// Decompiled with JetBrains decompiler
// Type: Shelf.Models.ShelfCountingResult
// Assembly: Shelf, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 34392FE8-51B4-4368-914A-8B6FB98A7971
// Assembly location: C:\Users\pc\reverse_engineering\com.companyname.Shelf\assemblies\Shelf.dll

using System;

namespace Shelf.Models
{
  public class ShelfCountingResult
  {
    public int CountingDetailID { get; set; }

    public int CountingID { get; set; }

    public string ShelfCode { get; set; }

    public string UsedBarcode { get; set; }

    public double Qty { get; set; }

    public string LotBarcode { get; set; }

    public DateTime CreatedDate { get; set; }

    public string CreatedUserName { get; set; }

    public DateTime UpdatedDate { get; set; }

    public string UpdatedUserName { get; set; }

    public string ItemCode { get; set; }

    public string ColorCode { get; set; }

    public string ItemDim1Code { get; set; }

    public string ItemDim2Code { get; set; }

    public string ItemDim3Code { get; set; }
  }
}
