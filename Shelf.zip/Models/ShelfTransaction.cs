﻿// Decompiled with JetBrains decompiler
// Type: Shelf.Models.ShelfTransaction
// Assembly: Shelf, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 34392FE8-51B4-4368-914A-8B6FB98A7971
// Assembly location: C:\Users\pc\reverse_engineering\com.companyname.Shelf\assemblies\Shelf.dll

namespace Shelf.Models
{
  public class ShelfTransaction
  {
    public string PackageNumber { get; set; }

    public int ShelfID { get; set; }

    public int ProcessTypeID { get; set; }

    public string WareHouseCode { get; set; }

    public string Barcode { get; set; }

    public string UserName { get; set; }

    public int ShelfTransID { get; set; }

    public int Qty { get; set; }

    public int TransTypeID { get; set; }

    public string DocumentNumber { get; set; }

    public int ShelfOrderDetailID { get; set; }

    public int ShelfOrderID { get; set; }

    public int ItemTypeCode { get; set; }

    public string ItemCode { get; set; }

    public string ColorCode { get; set; }

    public string ItemDim1Code { get; set; }

    public string ItemDim2Code { get; set; }

    public string ItemDim3Code { get; set; }

    public bool isLot { get; set; }

    public bool isUnique { get; set; }

    public string ColorDescription { get; set; }

    public string ItemDescription { get; set; }

    public string ColorCodeAndDescription => this.ColorDescription + "-" + this.ColorCode;

    public string ShelfCode { get; set; }

    public bool LastReadBarcode { get; set; }

    public string Description { get; set; }
  }
}
