﻿// Decompiled with JetBrains decompiler
// Type: Shelf.Models.TransType
// Assembly: Shelf, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 34392FE8-51B4-4368-914A-8B6FB98A7971
// Assembly location: C:\Users\pc\reverse_engineering\com.companyname.Shelf\assemblies\Shelf.dll

namespace Shelf.Models
{
  public enum TransType
  {
    Picking = 1,
    Basket = 2,
    ShelfEntry = 3,
    ShelfOutput = 4,
    ShelfCounting = 5,
    GoodsIn = 6,
    Rulot = 7,
    Return = 8,
    ShelfChange = 9,
    VirtualInventory = 10, // 0x0000000A
    PickShelfOutput = 11, // 0x0000000B
    PickMissing = 12, // 0x0000000C
    MinusInventoryCorrection = 13, // 0x0000000D
    UnlinkProduct = 14, // 0x0000000E
    StoreTransaction = 15, // 0x0000000F
    SetSolve = 16, // 0x00000010
    GoodsInProduction = 17, // 0x00000011
    MKToShelf = 18, // 0x00000012
    ShelfCountingShelfClear = 19, // 0x00000013
    MobileShelfItems = 20, // 0x00000014
    ReturnPool = 21, // 0x00000015
  }
}
