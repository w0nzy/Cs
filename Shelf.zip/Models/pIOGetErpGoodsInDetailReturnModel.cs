﻿// Decompiled with JetBrains decompiler
// Type: Shelf.Models.pIOGetErpGoodsInDetailReturnModel
// Assembly: Shelf, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 34392FE8-51B4-4368-914A-8B6FB98A7971
// Assembly location: C:\Users\pc\reverse_engineering\com.companyname.Shelf\assemblies\Shelf.dll

using System;

namespace Shelf.Models
{
  public class pIOGetErpGoodsInDetailReturnModel
  {
    public byte ItemTypeCode { get; set; }

    public string ItemCode { get; set; }

    public string ColorCode { get; set; }

    public string ItemDim1Code { get; set; }

    public string ItemDim2Code { get; set; }

    public string ItemDim3Code { get; set; }

    public Guid ShipmentLineID { get; set; }

    public double Qty { get; set; }

    public string Barcode { get; set; }

    public int? AlcQty { get; set; }

    public int? AllocateID { get; set; }

    public int RemainingQty => Convert.ToInt32(this.Qty) - Convert.ToInt32((object) this.AlcQty);
  }
}
