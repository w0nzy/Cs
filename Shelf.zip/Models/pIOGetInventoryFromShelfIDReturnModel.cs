﻿// Decompiled with JetBrains decompiler
// Type: Shelf.Models.pIOGetInventoryFromShelfIDReturnModel
// Assembly: Shelf, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 34392FE8-51B4-4368-914A-8B6FB98A7971
// Assembly location: C:\Users\pc\reverse_engineering\com.companyname.Shelf\assemblies\Shelf.dll

namespace Shelf.Models
{
  public class pIOGetInventoryFromShelfIDReturnModel
  {
    public bool UseSerialNumber { get; set; }

    public string ItemCodeLong => this.ItemCode + "-" + this.ColorCode + "-" + this.ItemDim1Code + (!string.IsNullOrEmpty(this.ItemDim2Code) ? "-" + this.ItemDim2Code : "");

    public string ItemDescription { get; set; }

    public string ShelfCode { get; set; }

    public int ShelfID { get; set; }

    public int? SortOrder { get; set; }

    public string WareHouseCode { get; set; }

    public int? ItemTypeCode { get; set; }

    public string ItemCode { get; set; }

    public string ColorCode { get; set; }

    public string ColorDescription { get; set; }

    public string ItemDim1Code { get; set; }

    public string ItemDim2Code { get; set; }

    public string ItemDim3Code { get; set; }

    public string Barcode { get; set; }

    public double? InventoryQty { get; set; }

    public double? RemainingOrderQty { get; set; }

    public double? AvailableInventoryQty { get; set; }

    public double ReadQty { get; set; }

    public bool IsSelected { get; set; }

    public string Url { get; set; }

    public string UsedBarcode { get; set; }

    public bool LastReadBarcode { get; set; }

    public string ItemDimCode
    {
      get
      {
        string itemDimCode = this.ItemDim1Code;
        if (!string.IsNullOrEmpty(this.ItemDim2Code))
          itemDimCode = itemDimCode + "-" + this.ItemDim2Code;
        if (!string.IsNullOrEmpty(this.ItemDim3Code))
          itemDimCode = itemDimCode + "-" + this.ItemDim3Code;
        return itemDimCode;
      }
    }

    public string RowColorCode
    {
      get
      {
        double readQty1 = this.ReadQty;
        double? inventoryQty1 = this.InventoryQty;
        double valueOrDefault = inventoryQty1.GetValueOrDefault();
        if (readQty1 == valueOrDefault & inventoryQty1.HasValue)
        {
          double? inventoryQty2 = this.InventoryQty;
          double num = 0.0;
          if (inventoryQty2.GetValueOrDefault() > num & inventoryQty2.HasValue)
            return "#7AC849";
        }
        double? inventoryQty3 = this.InventoryQty;
        double readQty2 = this.ReadQty;
        if (inventoryQty3.GetValueOrDefault() > readQty2 & inventoryQty3.HasValue && this.ReadQty > 0.0)
          return "DeepSkyBlue";
        double? inventoryQty4 = this.InventoryQty;
        double readQty3 = this.ReadQty;
        return inventoryQty4.GetValueOrDefault() < readQty3 & inventoryQty4.HasValue && this.ReadQty > 0.0 ? "Red" : "White";
      }
    }
  }
}
