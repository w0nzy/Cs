﻿// Decompiled with JetBrains decompiler
// Type: Shelf.Models.pIOGetItemsFromPackageBarcodeReturnModel
// Assembly: Shelf, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 34392FE8-51B4-4368-914A-8B6FB98A7971
// Assembly location: C:\Users\pc\reverse_engineering\com.companyname.Shelf\assemblies\Shelf.dll

namespace Shelf.Models
{
  public class pIOGetItemsFromPackageBarcodeReturnModel
  {
    public string ItemDescription { get; set; }

    public string ColorDescription { get; set; }

    public byte ItemTypeCode { get; set; }

    public string ItemCode { get; set; }

    public string ColorCode { get; set; }

    public string ItemDim1Code { get; set; }

    public string ItemDim2Code { get; set; }

    public string ItemDim3Code { get; set; }

    public double Qty1 { get; set; }

    public string PackageNumber { get; set; }

    public string Code { get; set; }

    public int? ShelfID { get; set; }

    public string ShelfCode { get; set; }

    public string Description { get; set; }

    public int? PlusOrderQty { get; set; }

    public int? MinusOrderQty { get; set; }
  }
}
