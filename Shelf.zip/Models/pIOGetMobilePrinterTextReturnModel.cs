﻿// Decompiled with JetBrains decompiler
// Type: Shelf.Models.pIOGetMobilePrinterTextReturnModel
// Assembly: Shelf, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 34392FE8-51B4-4368-914A-8B6FB98A7971
// Assembly location: C:\Users\pc\reverse_engineering\com.companyname.Shelf\assemblies\Shelf.dll

namespace Shelf.Models
{
  public class pIOGetMobilePrinterTextReturnModel
  {
    public int? PrinterBrandID { get; set; }

    public string PrintText { get; set; }
  }
}
