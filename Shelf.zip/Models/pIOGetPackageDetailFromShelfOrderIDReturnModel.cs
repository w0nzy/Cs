﻿// Decompiled with JetBrains decompiler
// Type: Shelf.Models.pIOGetPackageDetailFromShelfOrderIDReturnModel
// Assembly: Shelf, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 34392FE8-51B4-4368-914A-8B6FB98A7971
// Assembly location: C:\Users\pc\reverse_engineering\com.companyname.Shelf\assemblies\Shelf.dll

using System;

namespace Shelf.Models
{
  public class pIOGetPackageDetailFromShelfOrderIDReturnModel
  {
    public int PackageHeaderID { get; set; }

    public int ShelfOrderID { get; set; }

    public DateTime PackageDate { get; set; }

    public string PackageCode { get; set; }

    public int? PackageTypeID { get; set; }

    public string Description { get; set; }

    public string CustomerName { get; set; }

    public string ItemDescription { get; set; }

    public int ItemTypeCode { get; set; }

    public string ItemCode { get; set; }

    public string ColorCode { get; set; }

    public string ItemDim1Code { get; set; }

    public string ItemDim2Code { get; set; }

    public string ItemDim3Code { get; set; }

    public int Qty { get; set; }

    public string FileName { get; set; }

    public int? PrinterBrandID { get; set; }

    public bool? TurkishCharacterReplace { get; set; }

    public string ReportName { get; set; }

    public bool NetworkPrinter { get; set; }
  }
}
