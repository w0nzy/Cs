﻿// Decompiled with JetBrains decompiler
// Type: Shelf.Models.pIOGetPurchaseAllocatePackageReturnModel
// Assembly: Shelf, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 34392FE8-51B4-4368-914A-8B6FB98A7971
// Assembly location: C:\Users\pc\reverse_engineering\com.companyname.Shelf\assemblies\Shelf.dll

using System;

namespace Shelf.Models
{
  public class pIOGetPurchaseAllocatePackageReturnModel
  {
    public int PackageAllocateID { get; set; }

    public string PackageCode { get; set; }

    public int? PackageQty { get; set; }

    public DateTime PackageDate { get; set; }

    public int AllocateID { get; set; }

    public byte CurrAccTypeCode { get; set; }

    public string CurrAccCode { get; set; }

    public Guid? SubCurrAccID { get; set; }

    public bool IsCompleted { get; set; }

    public bool IsApproved { get; set; }

    public bool IsPostToV3 { get; set; }

    public string ShippingNumber { get; set; }

    public DateTime CreatedDate { get; set; }

    public string CreatedUserName { get; set; }

    public DateTime UpdatedDate { get; set; }

    public string UpdatedUserName { get; set; }

    public bool LastReadBarcode { get; set; }

    public string RowColorCode
    {
      get
      {
        if (this.IsCompleted)
          return "#7AC849";
        return this.LastReadBarcode ? "DeepSkyBlue" : "White";
      }
    }
  }
}
