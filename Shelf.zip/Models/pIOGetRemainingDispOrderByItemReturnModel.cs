﻿// Decompiled with JetBrains decompiler
// Type: Shelf.Models.pIOGetRemainingDispOrderByItemReturnModel
// Assembly: Shelf, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 34392FE8-51B4-4368-914A-8B6FB98A7971
// Assembly location: C:\Users\pc\reverse_engineering\com.companyname.Shelf\assemblies\Shelf.dll

using System;

namespace Shelf.Models
{
  public class pIOGetRemainingDispOrderByItemReturnModel
  {
    public bool IsFree { get; set; }

    public string Asorti { get; set; }

    public string ColorDescription { get; set; }

    public int? Priority { get; set; }

    public string CustomerCode { get; set; }

    public byte CustomerTypeCode { get; set; }

    public string CustomerDesc { get; set; }

    public string SelectionDesc { get; set; }

    public string SelectionCode { get; set; }

    public string DispOrderNumber { get; set; }

    public Guid? SubCurrAccID { get; set; }

    public string SubCurrAccCode { get; set; }

    public string CompanyName { get; set; }

    public Guid DispOrderHeaderID { get; set; }

    public Guid OrderLineID { get; set; }

    public string Barcode { get; set; }

    public byte ItemTypeCode { get; set; }

    public string ItemCode { get; set; }

    public string ColorCode { get; set; }

    public string ItemDim1Code { get; set; }

    public string ItemDim2Code { get; set; }

    public string ItemDim3Code { get; set; }

    public string ShelfCodes { get; set; }

    public int? ShelfID { get; set; }

    public double Qty { get; set; }

    public int? AlcQty { get; set; }

    public int? ShipmentRemainingQty { get; set; }

    public bool LastReadBarcode { get; set; }

    public string RowColorCode
    {
      get
      {
        double qty = this.Qty;
        int? alcQty = this.AlcQty;
        double? nullable = alcQty.HasValue ? new double?((double) alcQty.GetValueOrDefault()) : new double?();
        double valueOrDefault = nullable.GetValueOrDefault();
        if (qty == valueOrDefault & nullable.HasValue && this.Qty > 0.0)
          return "#7AC849";
        return this.LastReadBarcode ? "DeepSkyBlue" : "White";
      }
    }
  }
}
