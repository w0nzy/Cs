﻿// Decompiled with JetBrains decompiler
// Type: Shelf.Models.pIOGetShelfFromBarcodeReturnModel
// Assembly: Shelf, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 34392FE8-51B4-4368-914A-8B6FB98A7971
// Assembly location: C:\Users\pc\reverse_engineering\com.companyname.Shelf\assemblies\Shelf.dll

namespace Shelf.Models
{
  public class pIOGetShelfFromBarcodeReturnModel
  {
    public string ItemDescription { get; set; }

    public string ItemCode { get; set; }

    public string ColorCode { get; set; }

    public string ItemDim1Code { get; set; }

    public string ItemDim2Code { get; set; }

    public string ItemDim3Code { get; set; }

    public string ShelfCode { get; set; }

    public int? Qty { get; set; }

    public int? PurchaseOrderDetailID { get; set; }

    public string Url { get; set; }

    public int? MainShelfID { get; set; }

    public string MainShelfCode { get; set; }

    public string MainShelfDescription { get; set; }

    public string MainAndSubShelfCode
    {
      get
      {
        string mainAndSubShelfCode = this.ShelfCode;
        if (!string.IsNullOrEmpty(this.MainShelfCode))
          mainAndSubShelfCode = mainAndSubShelfCode + "(" + this.MainShelfCode + ")";
        return mainAndSubShelfCode;
      }
    }

    public string DimCode
    {
      get
      {
        string dimCode = this.ItemDim1Code;
        if (!string.IsNullOrEmpty(this.ItemDim2Code))
          dimCode = dimCode + "-" + this.ItemDim2Code;
        return dimCode;
      }
    }

    public string Description { get; set; }
  }
}
