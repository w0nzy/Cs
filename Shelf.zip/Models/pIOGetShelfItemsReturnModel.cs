﻿// Decompiled with JetBrains decompiler
// Type: Shelf.Models.pIOGetShelfItemsReturnModel
// Assembly: Shelf, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 34392FE8-51B4-4368-914A-8B6FB98A7971
// Assembly location: C:\Users\pc\reverse_engineering\com.companyname.Shelf\assemblies\Shelf.dll

namespace Shelf.Models
{
  public class pIOGetShelfItemsReturnModel
  {
    public string ItemCode { get; set; }

    public string ItemDescription { get; set; }

    public string ColorCode { get; set; }

    public string ColorDescription { get; set; }

    public string ColorCodeAndDesc => this.ColorDescription + "-" + this.ColorCode;

    public string ItemDimCode
    {
      get
      {
        string itemDimCode = this.ItemDim1Code;
        if (!string.IsNullOrEmpty(this.ItemDim2Code))
          itemDimCode = itemDimCode + "-" + this.ItemDim2Code;
        return itemDimCode;
      }
    }

    public string ItemDim1Code { get; set; }

    public string ItemDim2Code { get; set; }

    public string ItemDim3Code { get; set; }

    public int? Qty { get; set; }

    public string Barcode { get; set; }

    public bool IgnoreEntryComplete { get; set; }
  }
}
