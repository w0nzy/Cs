﻿// Decompiled with JetBrains decompiler
// Type: Shelf.Models.pIOGetStorePickMissingOrderReturnModel
// Assembly: Shelf, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 34392FE8-51B4-4368-914A-8B6FB98A7971
// Assembly location: C:\Users\pc\reverse_engineering\com.companyname.Shelf\assemblies\Shelf.dll

using System;

namespace Shelf.Models
{
  public class pIOGetStorePickMissingOrderReturnModel
  {
    public int ItemTypeCode { get; set; }

    public string ItemCode { get; set; }

    public string ColorCode { get; set; }

    public string ItemDim1Code { get; set; }

    public string ItemDim2Code { get; set; }

    public string ItemDim3Code { get; set; }

    public int PickMissingOrderID { get; set; }

    public int ShelfOrderPickMissingID { get; set; }

    public Guid? OrderLineID { get; set; }

    public string ToWarehouseCode { get; set; }

    public double? Qty { get; set; }

    public double? ApproveQty { get; set; }

    public int ShelfOrderDetailID { get; set; }

    public int ShelfOrderID { get; set; }

    public string ShelfOrderNumber { get; set; }

    public string ItemDescription { get; set; }

    public byte ShelfOrderType { get; set; }

    public string DispOrderNumber { get; set; }

    public bool LastReadBarcode { get; set; }

    public string RowColorCode
    {
      get
      {
        double? qty1 = this.Qty;
        double? approveQty1 = this.ApproveQty;
        double? approveQty2;
        if (qty1.GetValueOrDefault() == approveQty1.GetValueOrDefault() & qty1.HasValue == approveQty1.HasValue)
        {
          approveQty2 = this.ApproveQty;
          double num = 0.0;
          if (approveQty2.GetValueOrDefault() > num & approveQty2.HasValue)
            return "#7AC849";
        }
        approveQty2 = this.ApproveQty;
        double? qty2 = this.Qty;
        if (approveQty2.GetValueOrDefault() > qty2.GetValueOrDefault() & approveQty2.HasValue & qty2.HasValue)
          return "#ff0061";
        return this.LastReadBarcode ? "DeepSkyBlue" : "White";
      }
    }

    public string ItemCodeLong => this.ItemCode + "-" + this.ColorCode + "-" + this.ItemDim1Code + (!string.IsNullOrEmpty(this.ItemDim2Code) ? "-" + this.ItemDim2Code : "");

    public string Barcode { get; set; }
  }
}
