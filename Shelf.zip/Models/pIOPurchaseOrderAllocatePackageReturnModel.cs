﻿// Decompiled with JetBrains decompiler
// Type: Shelf.Models.pIOPurchaseOrderAllocatePackageReturnModel
// Assembly: Shelf, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 34392FE8-51B4-4368-914A-8B6FB98A7971
// Assembly location: C:\Users\pc\reverse_engineering\com.companyname.Shelf\assemblies\Shelf.dll

using System;

namespace Shelf.Models
{
  public class pIOPurchaseOrderAllocatePackageReturnModel
  {
    public string ItemCode { get; set; }

    public string ItemDescription { get; set; }

    public string ColorCode { get; set; }

    public string ColorDescription { get; set; }

    public string Barcode { get; set; }

    public byte ItemTypeCode { get; set; }

    public string ItemDim1Code { get; set; }

    public string ItemDim2Code { get; set; }

    public string ItemDim3Code { get; set; }

    public Guid OrderLineID { get; set; }

    public string OrderNumber { get; set; }

    public Guid OrderHeaderID { get; set; }

    public byte CurrAccTypeCode { get; set; }

    public string CurrAccCode { get; set; }

    public Guid? SubCurrAccID { get; set; }

    public double Qty1 { get; set; }

    public int? PDetailQty { get; set; }

    public double? OrderQty { get; set; }

    public bool LastReadBarcode { get; set; }

    public string RowColorCode
    {
      get
      {
        double qty1 = this.Qty1;
        int? pdetailQty = this.PDetailQty;
        double? nullable = pdetailQty.HasValue ? new double?((double) pdetailQty.GetValueOrDefault()) : new double?();
        double valueOrDefault = nullable.GetValueOrDefault();
        if (qty1 == valueOrDefault & nullable.HasValue && this.Qty1 > 0.0)
          return "#7AC849";
        return this.LastReadBarcode ? "DeepSkyBlue" : "White";
      }
    }

    public string LotBarcode { get; set; }

    public int? OrderLineSumID { get; set; }

    public int? LotQty { get; set; }

    public string LotCode { get; set; }
  }
}
