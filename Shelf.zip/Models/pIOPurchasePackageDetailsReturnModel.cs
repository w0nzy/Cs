﻿// Decompiled with JetBrains decompiler
// Type: Shelf.Models.pIOPurchasePackageDetailsReturnModel
// Assembly: Shelf, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 34392FE8-51B4-4368-914A-8B6FB98A7971
// Assembly location: C:\Users\pc\reverse_engineering\com.companyname.Shelf\assemblies\Shelf.dll

using System;

namespace Shelf.Models
{
  public class pIOPurchasePackageDetailsReturnModel
  {
    public int PackageAllocateDetailID { get; set; }

    public int PackageAllocateID { get; set; }

    public Guid OrderLineID { get; set; }

    public Guid DispOrderLineID { get; set; }

    public Guid? ShipmentLineID { get; set; }

    public int OrderQty { get; set; }

    public int ApproveQty { get; set; }

    public int ShippedQty { get; set; }

    public DateTime CreatedDate { get; set; }

    public string CreatedUserName { get; set; }

    public DateTime UpdatedDate { get; set; }

    public string UpdatedUserName { get; set; }

    public byte ItemTypeCode { get; set; }

    public string ItemCode { get; set; }

    public string ColorCode { get; set; }

    public string ItemDim1Code { get; set; }

    public string ItemDim2Code { get; set; }

    public string ItemDim3Code { get; set; }

    public string Barcode { get; set; }

    public string ItemDescription { get; set; }

    public bool LastReadBarcode { get; set; }

    public string ItemCodeLong => this.ItemCode + this.ColorCode + this.ItemDim1Code;

    public string RowColorCode
    {
      get
      {
        if (this.ApproveQty == this.OrderQty)
          return "#7AC849";
        return this.LastReadBarcode ? "DeepSkyBlue" : "White";
      }
    }
  }
}
