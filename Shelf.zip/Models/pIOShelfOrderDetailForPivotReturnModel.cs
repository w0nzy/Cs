﻿// Decompiled with JetBrains decompiler
// Type: Shelf.Models.pIOShelfOrderDetailForPivotReturnModel
// Assembly: Shelf, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 34392FE8-51B4-4368-914A-8B6FB98A7971
// Assembly location: C:\Users\pc\reverse_engineering\com.companyname.Shelf\assemblies\Shelf.dll

namespace Shelf.Models
{
  public class pIOShelfOrderDetailForPivotReturnModel
  {
    public bool? MainAllocate { get; set; }

    public string ItemDescription { get; set; }

    public string ItemCode { get; set; }

    public string ItemDim1Code { get; set; }

    public string ColorCode { get; set; }

    public int? SortOrder { get; set; }

    public string ItemCodeLong => this.ItemCode + "-" + this.ColorCode + "-" + this.ItemDim1Code + (!string.IsNullOrEmpty(this.ItemDim2Code) ? "-" + this.ItemDim2Code : "");

    public string RowColorCode
    {
      get
      {
        if (this.PickingQty == this.ApproveQty && this.ApproveQty > 0.0)
          return "#7AC849";
        return this.LastReadBarcode ? "DeepSkyBlue" : "White";
      }
    }

    public bool LastReadBarcode { get; set; }

    public string ItemDim1CodeStr => !string.IsNullOrEmpty(this.ItemDim1Code) ? "Beden : " + this.ItemDim1Code : "";

    public string ItemDim2Code { get; set; }

    public string ItemDim2CodeStr => !string.IsNullOrEmpty(this.ItemDim2Code) ? "Kavala :" + this.ItemDim2Code : "";

    public double OrderQty { get; set; }

    public string OrderQtyStr => this.OrderQty > 0.0 ? "Sip Miktarı : " + this.OrderQty.ToString() : "";

    public int PackedQty { get; set; }

    public string PackedQtyStr => this.PackedQty > 0 ? "Pak Miktarı : " + this.PackedQty.ToString() : "";

    public double PickingQty { get; set; }

    public string PickingQtyStr => this.PickingQty > 0.0 ? "Onay Miktar : " + this.PickingQty.ToString() : "";

    public double ApproveQty { get; set; }

    public string ApproveQtyStr => this.PickingQty > 0.0 ? "Onay Miktar : " + this.ApproveQty.ToString() : "";

    public int ShelfOrderDetailID { get; set; }

    public int ShelfOrderID { get; set; }

    public string Barcode { get; set; }

    public string ShelfCode { get; set; }

    public string ShelfName { get; set; }

    public string DispOrderNumber { get; set; }

    public byte ShelfOrderType { get; set; }

    public string UserName { get; set; }

    public int ShelfType { get; set; }

    public string PivotShelfCode { get; set; }
  }
}
