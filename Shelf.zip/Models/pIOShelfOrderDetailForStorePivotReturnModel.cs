﻿// Decompiled with JetBrains decompiler
// Type: Shelf.Models.pIOShelfOrderDetailForStorePivotReturnModel
// Assembly: Shelf, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 34392FE8-51B4-4368-914A-8B6FB98A7971
// Assembly location: C:\Users\pc\reverse_engineering\com.companyname.Shelf\assemblies\Shelf.dll

using System;

namespace Shelf.Models
{
  public class pIOShelfOrderDetailForStorePivotReturnModel
  {
    public string FirstLastName { get; set; }

    public int? ShelfUserID { get; set; }

    public string CurrAccCode { get; set; }

    public byte? CurrAccTypeCode { get; set; }

    public Guid? SubCurrAccID { get; set; }

    public string CustomerName { get; set; }

    public string ItemDescription { get; set; }

    public string ItemCode { get; set; }

    public string ColorCode { get; set; }

    public string ItemDim1Code { get; set; }

    public string ItemDim2Code { get; set; }

    public double OrderQty { get; set; }

    public double PickingQty { get; set; }

    public int PackedQty { get; set; }

    public double ApproveQty { get; set; }

    public int ShelfOrderDetailID { get; set; }

    public int ShelfOrderID { get; set; }

    public string Barcode { get; set; }

    public string ShelfCode { get; set; }

    public string ShelfName { get; set; }

    public int? SortOrder { get; set; }

    public string DispOrderNumber { get; set; }

    public Guid DispOrderLineID { get; set; }

    public byte ShelfOrderType { get; set; }

    public string PackageCode { get; set; }

    public int? PackageHeaderID { get; set; }

    public int? PackageDetailID { get; set; }

    public string LotBarcode { get; set; }

    public int? OrderLineSumID { get; set; }

    public string ItemCodeLong => this.ItemCode + "-" + this.ColorCode + "-" + this.ItemDim1Code + (!string.IsNullOrEmpty(this.ItemDim2Code) ? "-" + this.ItemDim2Code : "");

    public string RowColorCode
    {
      get
      {
        if (this.PickingQty == this.ApproveQty && this.ApproveQty > 0.0)
          return "#7AC849";
        return this.LastReadBarcode ? "DeepSkyBlue" : "White";
      }
    }

    public bool LastReadBarcode { get; set; }
  }
}
