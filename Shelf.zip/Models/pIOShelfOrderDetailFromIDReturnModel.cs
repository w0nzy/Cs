﻿// Decompiled with JetBrains decompiler
// Type: Shelf.Models.pIOShelfOrderDetailFromIDReturnModel
// Assembly: Shelf, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 34392FE8-51B4-4368-914A-8B6FB98A7971
// Assembly location: C:\Users\pc\reverse_engineering\com.companyname.Shelf\assemblies\Shelf.dll

using System;

namespace Shelf.Models
{
  public class pIOShelfOrderDetailFromIDReturnModel
  {
    public bool UseSerialNumber { get; set; }

    public int CurrAccTypeCode { get; set; }

    public string CurrAccCode { get; set; }

    public Guid? SubCurrAccID { get; set; }

    public string ItemDescription { get; set; }

    public string ItemCode { get; set; }

    public string ItemDim1Code { get; set; }

    public string ColorCode { get; set; }

    public int? SortOrder { get; set; }

    public double SubSortOrder { get; set; }

    public string ItemCodeLong => this.ItemCode + "-" + this.ColorCode + "-" + this.ItemDim1Code + (!string.IsNullOrEmpty(this.ItemDim2Code) ? "-" + this.ItemDim2Code : "");

    public string RowColorCode
    {
      get
      {
        if (this.OrderQty == this.PickingQty && this.PickingQty > 0.0)
          return "#7AC849";
        return this.LastReadBarcode ? "DeepSkyBlue" : "White";
      }
    }

    public string GroupRowColorCode
    {
      get
      {
        if (this.OrderQty == this.PickingQty && this.PickingQty > 0.0)
          return "#7AC849";
        return this.PickingQty > 0.0 ? "DeepSkyBlue" : "Transparent";
      }
    }

    public bool LastReadBarcode { get; set; }

    public string ItemDim1CodeStr => !string.IsNullOrEmpty(this.ItemDim1Code) ? "Beden : " + this.ItemDim1Code : "";

    public string ItemDim2Code { get; set; }

    public string ItemDim2CodeStr => !string.IsNullOrEmpty(this.ItemDim2Code) ? "Kavala :" + this.ItemDim2Code : "";

    public double OrderQty { get; set; }

    public string OrderQtyStr
    {
      get
      {
        if (this.OrderQty <= 0.0)
          return "";
        double num = this.OrderQty;
        string str1 = num.ToString();
        num = this.OrderQty - this.PickingQty;
        string str2 = num.ToString();
        return "Sip./Kalan: " + str1 + "/" + str2;
      }
    }

    public int PackedQty { get; set; }

    public string PackedQtyStr => this.PackedQty > 0 ? "Pak Miktarı : " + this.PackedQty.ToString() : "";

    public double PickingQty { get; set; }

    public string PickingQtyStr => this.PickingQty > 0.0 ? "Top. Miktar: " + this.PickingQty.ToString() : "";

    public double ApproveQty { get; set; }

    public string ApproveQtyStr => this.PickingQty > 0.0 ? "Onay Miktar : " + this.ApproveQty.ToString() : "";

    public int ShelfOrderDetailID { get; set; }

    public int ShelfOrderID { get; set; }

    public string ShelfOrderNumber { get; set; }

    public string Barcode { get; set; }

    public string ShelfCode { get; set; }

    public string ShelfName { get; set; }

    public string DispOrderNumber { get; set; }

    public byte ShelfOrderType { get; set; }

    public string Url { get; set; }

    public string HallCode { get; set; }

    public string FloorCode { get; set; }

    public int ShelfID { get; set; }

    public string WarehouseCode { get; set; }

    public string PackageHeaderIds { get; set; }

    public string PackageCode { get; set; }

    public int? PackageHeaderID { get; set; }

    public int? PackageDetailID { get; set; }

    public Guid DispOrderLineID { get; set; }

    public bool? AutoApproveQty { get; set; }

    public bool? AutoPackedQty { get; set; }

    public byte? ShelfCurrAccTypeCode { get; set; }

    public string PackageBarcode { get; set; }

    public string MainShelfCode { get; set; }

    public string MainShelfDescription { get; set; }

    public string LotBarcode { get; set; }

    public int? OrderLineSumID { get; set; }

    public int? LotQty { get; set; }

    public string LotCode { get; set; }

    public string UsedBarcode { get; set; }
  }
}
