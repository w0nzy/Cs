﻿// Decompiled with JetBrains decompiler
// Type: Shelf.Models.pIOShelfOrderDetailFromPackageReturnModel
// Assembly: Shelf, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 34392FE8-51B4-4368-914A-8B6FB98A7971
// Assembly location: C:\Users\pc\reverse_engineering\com.companyname.Shelf\assemblies\Shelf.dll

using System;

namespace Shelf.Models
{
  public class pIOShelfOrderDetailFromPackageReturnModel
  {
    public bool UseSerialNumber { get; set; }

    public string RowColorCode
    {
      get
      {
        double pickingQty = this.PickingQty;
        int? packageApproveQty = this.PackageApproveQty;
        double? nullable = packageApproveQty.HasValue ? new double?((double) packageApproveQty.GetValueOrDefault()) : new double?();
        double valueOrDefault = nullable.GetValueOrDefault();
        if (pickingQty == valueOrDefault & nullable.HasValue)
        {
          packageApproveQty = this.PackageApproveQty;
          int num = 0;
          if (packageApproveQty.GetValueOrDefault() > num & packageApproveQty.HasValue)
            return "#7AC849";
        }
        return this.LastReadBarcode ? "DeepSkyBlue" : "White";
      }
    }

    public bool LastReadBarcode { get; set; }

    public string ItemCodeLong => this.ItemCode + "-" + this.ColorCode + "-" + this.ItemDim1Code + (!string.IsNullOrEmpty(this.ItemDim2Code) ? "-" + this.ItemDim2Code : "");

    public string LotBarcode { get; set; }

    public int? OrderLineSumID { get; set; }

    public int? LotQty { get; set; }

    public string LotCode { get; set; }

    public string ItemDescription { get; set; }

    public string ItemCode { get; set; }

    public string ColorCode { get; set; }

    public string ItemDim1Code { get; set; }

    public string ItemDim2Code { get; set; }

    public double OrderQty { get; set; }

    public double PickingQty { get; set; }

    public int PackedQty { get; set; }

    public double ApproveQty { get; set; }

    public int ShelfOrderDetailID { get; set; }

    public string PackageBarcode { get; set; }

    public int ShelfOrderID { get; set; }

    public string Barcode { get; set; }

    public string UsedBarcode { get; set; }

    public string ShelfCode { get; set; }

    public string HallCode { get; set; }

    public string FloorCode { get; set; }

    public string ShelfName { get; set; }

    public int? SortOrder { get; set; }

    public string ShelfOrderNumber { get; set; }

    public string DispOrderNumber { get; set; }

    public Guid DispOrderLineID { get; set; }

    public string Url { get; set; }

    public int ShelfID { get; set; }

    public string WarehouseCode { get; set; }

    public byte ShelfOrderType { get; set; }

    public string PackageCode { get; set; }

    public int? PackageHeaderID { get; set; }

    public int? PackageDetailID { get; set; }

    public bool? AutoApproveQty { get; set; }

    public bool? AutoPackedQty { get; set; }

    public int CurrAccTypeCode { get; set; }

    public Guid? SubCurrAccID { get; set; }

    public string CurrAccCode { get; set; }

    public string PackageHeaderIds { get; set; }

    public int? IsBlocked { get; set; }

    public string MainShelfCode { get; set; }

    public string MainShelfDescription { get; set; }

    public int? PackageApproveQty { get; set; }

    public string PackageDescription { get; set; }

    public string SetItemCode { get; set; }

    public int SetContentItemQty { get; set; }

    public int SetQty { get; set; }

    public string SetRowColorCode
    {
      get
      {
        double pickingQty = this.PickingQty;
        int? packageApproveQty = this.PackageApproveQty;
        double? nullable = packageApproveQty.HasValue ? new double?((double) packageApproveQty.GetValueOrDefault()) : new double?();
        double valueOrDefault = nullable.GetValueOrDefault();
        if (pickingQty == valueOrDefault & nullable.HasValue)
        {
          packageApproveQty = this.PackageApproveQty;
          int num = 0;
          if (packageApproveQty.GetValueOrDefault() > num & packageApproveQty.HasValue)
            return "#7AC849";
        }
        if (this.SetContentItemQty <= 0)
          return "";
        return this.SetReadQty == this.SetContentItemQty ? "DeepSkyBlue" : "Red";
      }
    }

    public int SetReadQty { get; set; }

    public string SetRemainingQty
    {
      get
      {
        int num = this.SetContentItemQty;
        string str1 = num.ToString();
        num = this.SetReadQty;
        string str2 = num.ToString();
        return str1 + "/" + str2;
      }
    }
  }
}
