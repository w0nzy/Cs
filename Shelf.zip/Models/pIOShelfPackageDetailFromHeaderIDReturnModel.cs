﻿// Decompiled with JetBrains decompiler
// Type: Shelf.Models.pIOShelfPackageDetailFromHeaderIDReturnModel
// Assembly: Shelf, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 34392FE8-51B4-4368-914A-8B6FB98A7971
// Assembly location: C:\Users\pc\reverse_engineering\com.companyname.Shelf\assemblies\Shelf.dll

namespace Shelf.Models
{
  public class pIOShelfPackageDetailFromHeaderIDReturnModel
  {
    public string ItemDescription { get; set; }

    public string ItemCode { get; set; }

    public string Barcode { get; set; }

    public string ColorDescription { get; set; }

    public string ColorCode { get; set; }

    public string ItemDim1Code { get; set; }

    public int? Qty { get; set; }

    public string ShippingNumber { get; set; }

    public string ShippingAddress { get; set; }

    public string MainAddress { get; set; }

    public string CurrAccCode { get; set; }

    public string CurrAccDesc { get; set; }

    public string CompanyName { get; set; }
  }
}
