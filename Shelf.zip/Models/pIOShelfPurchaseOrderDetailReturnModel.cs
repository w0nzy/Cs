﻿// Decompiled with JetBrains decompiler
// Type: Shelf.Models.pIOShelfPurchaseOrderDetailReturnModel
// Assembly: Shelf, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 34392FE8-51B4-4368-914A-8B6FB98A7971
// Assembly location: C:\Users\pc\reverse_engineering\com.companyname.Shelf\assemblies\Shelf.dll

namespace Shelf.Models
{
  public class pIOShelfPurchaseOrderDetailReturnModel
  {
    public bool UseSerialNumber { get; set; }

    public bool? PlusOrderQty { get; set; }

    public string ItemDescription { get; set; }

    public string ItemCode { get; set; }

    public string ColorCode { get; set; }

    public string ItemDim1Code { get; set; }

    public string ItemDim2Code { get; set; }

    public double OrderQty { get; set; }

    public double AllocatingQty { get; set; }

    public int PurchaseOrderDetailID { get; set; }

    public int PurchaseOrderID { get; set; }

    public string Barcode { get; set; }

    public string UsedBarcode { get; set; }

    public string ShelfCode { get; set; }

    public string ShelfName { get; set; }

    public int? SortOrder { get; set; }

    public bool LastReadBarcode { get; set; }

    public string ItemDescription2 => this.ItemDescription.Length > 25 ? this.ItemDescription.Substring(0, 25) + ".." : this.ItemDescription;

    public string RowColorCode
    {
      get
      {
        if (this.OrderQty == this.AllocatingQty && this.AllocatingQty > 0.0)
          return "#7AC849";
        if (this.AllocatingQty > this.OrderQty)
          return "#ff0061";
        return this.LastReadBarcode ? "DeepSkyBlue" : "White";
      }
    }

    public string ItemCodeLong => this.ItemCode + "-" + this.ColorCode + "-" + this.ItemDim1Code + (!string.IsNullOrEmpty(this.ItemDim2Code) ? "-" + this.ItemDim2Code : "");

    public string AllocatingQtyStr => this.AllocatingQty > 0.0 ? "Onay Miktar : " + this.AllocatingQty.ToString() : "";

    public string OrderQtyStr => this.OrderQty > 0.0 ? "Sip Miktarı : " + this.OrderQty.ToString() : "";

    public int PlusPercent { get; set; }
  }
}
