﻿// Decompiled with JetBrains decompiler
// Type: Shelf.Models.pIOUserShelfPurchaseOrdersReturnModel
// Assembly: Shelf, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 34392FE8-51B4-4368-914A-8B6FB98A7971
// Assembly location: C:\Users\pc\reverse_engineering\com.companyname.Shelf\assemblies\Shelf.dll

using System;

namespace Shelf.Models
{
  public class pIOUserShelfPurchaseOrdersReturnModel
  {
    public int PurchaseOrderID { get; set; }

    public string PurchaseOrderNumber { get; set; }

    public string WarehouseCode { get; set; }

    public DateTime? PurchaseOrderDate { get; set; }

    public int AssignedUserID { get; set; }

    public bool IsCompleted { get; set; }

    public DateTime? CreatedDate { get; set; }

    public string CreatedUserName { get; set; }

    public DateTime? UpdatedDate { get; set; }

    public string UpdatedUserName { get; set; }

    public string Description { get; set; }

    public string ShelfPrefix { get; set; }
  }
}
