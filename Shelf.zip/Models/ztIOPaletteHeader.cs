﻿// Decompiled with JetBrains decompiler
// Type: Shelf.Models.ztIOPaletteHeader
// Assembly: Shelf, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 34392FE8-51B4-4368-914A-8B6FB98A7971
// Assembly location: C:\Users\pc\reverse_engineering\com.companyname.Shelf\assemblies\Shelf.dll

using System;

namespace Shelf.Models
{
  public class ztIOPaletteHeader
  {
    public int PaletteHeaderID { get; set; }

    public string PaletteCode { get; set; }

    public string Description { get; set; }

    public bool IsCompleted { get; set; }

    public string CreatedUserName { get; set; }

    public DateTime CreatedDate { get; set; }

    public string UpdatedUserName { get; set; }

    public DateTime? UpdatedDate { get; set; }
  }
}
