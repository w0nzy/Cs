﻿// Decompiled with JetBrains decompiler
// Type: Shelf.Models.ztIOShelfCounting
// Assembly: Shelf, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 34392FE8-51B4-4368-914A-8B6FB98A7971
// Assembly location: C:\Users\pc\reverse_engineering\com.companyname.Shelf\assemblies\Shelf.dll

using System;

namespace Shelf.Models
{
  public class ztIOShelfCounting
  {
    public int CountingID { get; set; }

    public string CountingNumber { get; private set; }

    public DateTime CountingDate { get; set; }

    public string WarehouseCode { get; set; }

    public bool IsCompleted { get; set; }

    public bool FromFile { get; set; }

    public bool IsCanceled { get; set; }

    public int? TransactionID { get; set; }

    public string CreatedUserName { get; set; }

    public DateTime CreatedDate { get; set; }

    public string UpdatedUserName { get; set; }

    public DateTime UpdatedDate { get; set; }
  }
}
