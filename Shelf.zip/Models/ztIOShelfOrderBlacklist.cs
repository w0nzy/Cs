﻿// Decompiled with JetBrains decompiler
// Type: Shelf.Models.ztIOShelfOrderBlacklist
// Assembly: Shelf, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 34392FE8-51B4-4368-914A-8B6FB98A7971
// Assembly location: C:\Users\pc\reverse_engineering\com.companyname.Shelf\assemblies\Shelf.dll

using System;

namespace Shelf.Models
{
  public class ztIOShelfOrderBlacklist
  {
    public int ShelfOrderBlacklistID { get; set; }

    public int ShelfOrderID { get; set; }

    public int ShelfOrderDetailID { get; set; }

    public int ShelfID { get; set; }

    public int ItemTypeCode { get; set; }

    public string ItemCode { get; set; }

    public string ColorCode { get; set; }

    public string ItemDim1Code { get; set; }

    public string ItemDim2Code { get; set; }

    public string ItemDim3Code { get; set; }

    public bool IsBlocked { get; set; }

    public int Qty { get; set; }

    public DateTime? CreatedDate { get; set; }

    public string CreatedUserName { get; set; }

    public DateTime? UpdateDate { get; set; }

    public string UpdateUserName { get; set; }
  }
}
