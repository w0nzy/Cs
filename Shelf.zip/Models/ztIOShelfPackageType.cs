﻿// Decompiled with JetBrains decompiler
// Type: Shelf.Models.ztIOShelfPackageType
// Assembly: Shelf, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 34392FE8-51B4-4368-914A-8B6FB98A7971
// Assembly location: C:\Users\pc\reverse_engineering\com.companyname.Shelf\assemblies\Shelf.dll

using System;

namespace Shelf.Models
{
  public class ztIOShelfPackageType
  {
    public int PackageTypeID { get; set; }

    public string PackageType { get; set; }

    public Decimal? PackageWidth { get; set; }

    public Decimal? PackageLength { get; set; }

    public Decimal? PackageHeight { get; set; }

    public Decimal? PackageVolume { get; private set; }

    public string PackageDesc { get; set; }
  }
}
