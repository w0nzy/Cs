﻿// Decompiled with JetBrains decompiler
// Type: Shelf.Models.ztIOShelfTransactionDetail
// Assembly: Shelf, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 34392FE8-51B4-4368-914A-8B6FB98A7971
// Assembly location: C:\Users\pc\reverse_engineering\com.companyname.Shelf\assemblies\Shelf.dll

using System;
using System.Collections.Generic;

namespace Shelf.Models
{
  public class ztIOShelfTransactionDetail
  {
    public int TransactionDetailID { get; set; }

    public int TransactionID { get; set; }

    public int? ShelfOrderDetailID { get; set; }

    public int? ItemTypeCode { get; set; }

    public string ItemCode { get; set; }

    public string ColorCode { get; set; }

    public string ColorDescription { get; set; }

    public string ColorCodeAndDescription => this.ColorDescription + "-" + this.ColorCode;

    public string ItemDim1Code { get; set; }

    public string ItemDim2Code { get; set; }

    public string ItemDim3Code { get; set; }

    public string UsedBarcode { get; set; }

    public double? Qty { get; set; }

    public string QtyStr
    {
      get
      {
        double? qty = this.Qty;
        double num = 0.0;
        return qty.GetValueOrDefault() > num & qty.HasValue ? "Miktar : " + this.Qty.ToString() : "";
      }
    }

    public DateTime? CreatedDate { get; set; }

    public string CreatedUserName { get; set; }

    public DateTime? UpdatedDate { get; set; }

    public string UpdatedUserName { get; set; }

    public string ItemType { get; set; }

    public List<ztIOShelfTransactionDetail> detailList { get; set; }
  }
}
